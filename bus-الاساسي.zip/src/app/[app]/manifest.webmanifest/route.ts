import { getSettings } from "@/lib/settings";

const APPS: Record<string, { title: string; short: string; color: string }> = {
  passenger: { title: "تطبيق المسافر", short: "رحلتي", color: "#1d4ed8" },
  company: { title: "إدارة الشركات", short: "رحلتي - شركات", color: "#0f766e" },
  admin: { title: "مدير النظام", short: "رحلتي - إدارة", color: "#6d28d9" },
};

export async function GET(_req: Request, ctx: { params: Promise<{ app: string }> }) {
  const { app } = await ctx.params;
  const cfg = APPS[app];
  if (!cfg) return new Response("Not found", { status: 404 });
  const s = await getSettings();
  // أيقونة التطبيق المرفوعة من مدير النظام تُطبّق على تطبيق المسافر
  const custom = app === "passenger" && s.app_icon ? s.app_icon : null;
  // بدون حقل type: المتصفح يكتشف النوع الفعلي للصورة المرفوعة
  const icons = custom
    ? [
        { src: custom, sizes: "512x512", purpose: "any" },
        { src: custom, sizes: "192x192", purpose: "any" },
        { src: custom, sizes: "512x512", purpose: "maskable" },
      ]
    : [
        { src: `/icons/${app}-512.png`, sizes: "512x512", purpose: "any" },
        { src: `/icons/${app}-512.png`, sizes: "192x192", purpose: "any" },
        { src: `/icons/${app}-512.png`, sizes: "512x512", purpose: "maskable" },
      ];
  const color = app === "passenger" ? s.primary_color : cfg.color;
  return Response.json(
    {
      id: `/${app}`,
      name: `${s.app_name} - ${cfg.title}`,
      short_name: app === "passenger" ? (s.app_name.length <= 12 ? s.app_name : s.app_name.split(" ")[0]) : cfg.short,
      description: cfg.title,
      start_url: `/${app}`,
      scope: `/${app}/`,
      display: "standalone",
      orientation: "portrait",
      dir: "rtl",
      lang: "ar",
      background_color: "#f1f5f9",
      theme_color: color,
      icons,
    },
    { headers: { "content-type": "application/manifest+json", "cache-control": "no-cache" } },
  );
}
