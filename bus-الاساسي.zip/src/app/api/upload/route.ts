import { randomUUID } from "node:crypto";
import { db } from "@/db";
import { files } from "@/db/schema";
import { anySession } from "@/lib/auth";

export const dynamic = "force-dynamic";

const ALLOWED = ["image/jpeg", "image/png", "image/webp", "image/gif", "application/pdf"];

export async function POST(req: Request) {
  if (!(await anySession())) return Response.json({ error: "يجب تسجيل الدخول" }, { status: 401 });
  const fd = await req.formData();
  const f = fd.get("file");
  if (!(f instanceof File)) return Response.json({ error: "لم يتم اختيار ملف" }, { status: 400 });
  if (!ALLOWED.includes(f.type)) return Response.json({ error: "نوع الملف غير مسموح" }, { status: 400 });
  if (f.size > 4 * 1024 * 1024) return Response.json({ error: "حجم الملف أكبر من 4 ميغابايت" }, { status: 400 });
  const id = randomUUID();
  const buf = Buffer.from(await f.arrayBuffer());
  await db.insert(files).values({ id, mime: f.type, data: buf.toString("base64") });
  return Response.json({ url: `/api/files/${id}${f.type === "application/pdf" ? "?f=.pdf" : ""}` });
}
