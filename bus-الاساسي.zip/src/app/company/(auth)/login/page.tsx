import { AuthShell } from "@/components/auth-shell";
import { Field, Flash, btnCls, inputCls } from "@/components/ui";
import { companyLoginAction } from "../../actions";

export const metadata = { title: "تسجيل الدخول" };

export default async function CompanyLogin({ searchParams }: { searchParams: Promise<Record<string, string | string[] | undefined>> }) {
  const sp = await searchParams;
  return (
    <AuthShell title="دخول إدارة الشركة" subtitle="للموظفين ومديري المكاتب" badge="تطبيق إدارة الشركات" returnTo="/company/login">
      <Flash sp={sp} />
      <form action={companyLoginAction} className="space-y-4">
        <Field label="البريد الإلكتروني أو رقم الهاتف">
          <input name="identifier" required className={inputCls} />
        </Field>
        <Field label="كلمة المرور">
          <input name="password" type="password" required className={inputCls} />
        </Field>
        <button className={`${btnCls()} w-full`}>تسجيل الدخول</button>
      </form>
      <div className="mt-5 space-y-1 rounded-xl bg-slate-50 p-3 text-xs text-slate-500">
        <div>مدير مكتب: <b dir="ltr">nile.manager@bus.sd</b> / <b dir="ltr">manager123</b></div>
        <div>موظف: <b dir="ltr">nile.emp@bus.sd</b> / <b dir="ltr">emp123</b></div>
      </div>
    </AuthShell>
  );
}
