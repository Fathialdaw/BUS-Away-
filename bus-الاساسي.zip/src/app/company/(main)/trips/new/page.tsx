import { redirect } from "next/navigation";
import { Flash, PageTitle } from "@/components/ui";
import { TripForm } from "@/components/trip-form";
import { isManager, requireCompany } from "@/lib/auth";
import { getGeo } from "@/lib/trips";
import { saveTripAction } from "@/app/company/actions";

export const metadata = { title: "إضافة رحلة" };

export default async function NewTrip({ searchParams }: { searchParams: Promise<Record<string, string | string[] | undefined>> }) {
  const sp = await searchParams;
  const { user, company } = await requireCompany();
  if (!isManager(user)) redirect("/company/trips");
  const geo = await getGeo();
  return (
    <div>
      <PageTitle title="إضافة رحلة جديدة" subtitle={`ستُسجل الرحلة باسم ${company.name} فقط`} />
      <Flash sp={sp} />
      <TripForm geo={geo} action={saveTripAction} />
    </div>
  );
}
