import { redirect } from "next/navigation";
import { go } from "@/lib/nav";
import { and, asc, eq } from "drizzle-orm";
import { db } from "@/db";
import { users } from "@/db/schema";
import { Card, Empty, Field, Flash, PageTitle, StatusBadge, btnCls, inputCls } from "@/components/ui";
import { isManager, requireCompany } from "@/lib/auth";
import { PERMS, fmtDateTime, userStatus } from "@/lib/format";
import { addStaffAction, updateStaffAction } from "@/app/company/actions";

export const metadata = { title: "الموظفون" };

export default async function StaffPage({ searchParams }: { searchParams: Promise<Record<string, string | string[] | undefined>> }) {
  const sp = await searchParams;
  const { user, company } = await requireCompany();
  if (!isManager(user)) go("/company", { error: "هذه الصفحة لمدير المكتب فقط" });
  const rows = await db.select().from(users).where(and(eq(users.companyId, company.id), eq(users.role, "employee"))).orderBy(asc(users.id));
  const permBoxes = (cur: string[]) => (
    <div className="flex flex-wrap gap-3">
      {PERMS.map((p) => (
        <label key={p.key} className="flex items-center gap-1.5 text-xs">
          <input type="checkbox" name="perms" value={p.key} defaultChecked={cur.includes(p.key)} /> {p.label}
        </label>
      ))}
    </div>
  );
  return (
    <div className="space-y-4">
      <PageTitle title="موظفو الشركة" subtitle="إدارة الموظفين وتحديد صلاحياتهم" />
      <Flash sp={sp} />
      <Card>
        <h2 className="mb-3 text-sm font-bold">إضافة موظف</h2>
        <form action={addStaffAction} className="space-y-3">
          <div className="grid gap-3 sm:grid-cols-2">
            <Field label="الاسم"><input name="name" required className={inputCls} /></Field>
            <Field label="رقم الهاتف"><input name="phone" required className={inputCls} /></Field>
            <Field label="البريد الإلكتروني"><input name="email" type="email" className={inputCls} /></Field>
            <Field label="كلمة المرور"><input name="password" type="password" minLength={6} required className={inputCls} /></Field>
          </div>
          {permBoxes(["bookings", "payments", "scan"])}
          <button className={btnCls()}>إضافة الموظف</button>
        </form>
      </Card>
      {rows.length === 0 ? (
        <Empty text="لا يوجد موظفون" icon="👥" />
      ) : (
        <div className="grid gap-3 md:grid-cols-2">
          {rows.map((u) => (
            <Card key={u.id}>
              <div className="flex items-start justify-between">
                <div>
                  <div className="font-bold">{u.name}</div>
                  <div className="text-xs text-slate-500" dir="ltr">{u.phone} {u.email ? `• ${u.email}` : ""}</div>
                  <div className="mt-1 text-[11px] text-slate-400">آخر دخول: {fmtDateTime(u.lastLoginAt)}</div>
                </div>
                <StatusBadge map={userStatus} value={u.status} />
              </div>
              <form action={updateStaffAction} className="mt-3 space-y-3 border-t border-slate-100 pt-3">
                <input type="hidden" name="id" value={u.id} />
                {permBoxes(u.permissions ?? [])}
                <div className="grid grid-cols-2 gap-2">
                  <select name="status" defaultValue={u.status} className={inputCls}>
                    <option value="active">نشط</option>
                    <option value="disabled">معطل</option>
                  </select>
                  <input name="password" type="password" placeholder="كلمة مرور جديدة (اختياري)" className={inputCls} />
                </div>
                <button className={btnCls("outline", true)}>حفظ</button>
              </form>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
}
