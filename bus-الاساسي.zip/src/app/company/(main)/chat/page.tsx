import Link from "next/link";
import { redirect } from "next/navigation";
import { go } from "@/lib/nav";
import { and, desc, eq, inArray, ne } from "drizzle-orm";
import { db } from "@/db";
import { chatMembers, chatRooms, companies, messages, users } from "@/db/schema";
import { Card, Empty, Field, Flash, PageTitle, btnCls, inputCls } from "@/components/ui";
import { isManager, requireCompany } from "@/lib/auth";
import { fmtDateTime } from "@/lib/format";
import { getSettings } from "@/lib/settings";
import { createGroupChatAction, startDirectChatAction } from "@/app/company/actions";

export const metadata = { title: "الدردشة" };

export default async function ChatList({ searchParams }: { searchParams: Promise<Record<string, string | string[] | undefined>> }) {
  const sp = await searchParams;
  const { user } = await requireCompany();
  const s = await getSettings();
  if (!isManager(user) && s.employee_chat_allowed !== "true") go("/company", { error: "الدردشة مخصصة لمديري المكاتب" });
  const mine = await db.select({ room: chatRooms }).from(chatMembers).innerJoin(chatRooms, eq(chatRooms.id, chatMembers.roomId)).where(eq(chatMembers.userId, user.id));
  const ids = mine.map((m) => m.room.id);
  const members = ids.length
    ? await db
        .select({ roomId: chatMembers.roomId, uid: users.id, name: users.name, company: companies.name })
        .from(chatMembers)
        .innerJoin(users, eq(users.id, chatMembers.userId))
        .leftJoin(companies, eq(companies.id, users.companyId))
        .where(inArray(chatMembers.roomId, ids))
    : [];
  const last = ids.length ? await db.select().from(messages).where(inArray(messages.roomId, ids)).orderBy(desc(messages.id)) : [];
  const others = await db
    .select({ id: users.id, name: users.name, company: companies.name })
    .from(users)
    .leftJoin(companies, eq(companies.id, users.companyId))
    .where(and(eq(users.role, "company_manager"), eq(users.status, "active"), ne(users.id, user.id)));
  const rooms = mine
    .map(({ room }) => {
      const ms = members.filter((m) => m.roomId === room.id);
      const other = ms.find((m) => m.uid !== user.id);
      const lm = last.find((l) => l.roomId === room.id);
      return {
        room,
        title: room.isGroup ? room.name : `${other?.name ?? "-"} — ${other?.company ?? ""}`,
        sub: room.isGroup ? `${ms.length} أعضاء` : "محادثة فردية",
        lm,
      };
    })
    .sort((a, b) => (b.lm?.id ?? 0) - (a.lm?.id ?? 0));
  return (
    <div className="space-y-4">
      <PageTitle title="دردشة مديري المكاتب" subtitle="للتنسيق ومناقشة الأسعار والرحلات — لا تظهر للركاب" />
      <Flash sp={sp} />
      <div className="grid gap-4 md:grid-cols-2">
        <Card>
          <h2 className="mb-3 text-sm font-bold">محادثة فردية جديدة</h2>
          <form action={startDirectChatAction} className="flex gap-2">
            <select name="userId" required className={inputCls}>
              <option value="">اختر مدير مكتب</option>
              {others.map((o) => <option key={o.id} value={o.id}>{o.name} — {o.company}</option>)}
            </select>
            <button className={btnCls()}>بدء</button>
          </form>
        </Card>
        <Card>
          <h2 className="mb-3 text-sm font-bold">مجموعة جديدة</h2>
          <form action={createGroupChatAction} className="space-y-2">
            <Field label="اسم المجموعة"><input name="name" required className={inputCls} /></Field>
            <div className="flex flex-wrap gap-3">
              {others.map((o) => (
                <label key={o.id} className="flex items-center gap-1.5 text-xs"><input type="checkbox" name="members" value={o.id} /> {o.name} ({o.company})</label>
              ))}
            </div>
            <button className={btnCls("outline")}>إنشاء المجموعة</button>
          </form>
        </Card>
      </div>
      {rooms.length === 0 ? (
        <Empty text="لا توجد محادثات بعد" icon="💬" />
      ) : (
        <div className="space-y-2">
          {rooms.map(({ room, title, sub, lm }) => (
            <Link key={room.id} href={`/company/chat/${room.id}`} className="flex items-center justify-between rounded-2xl bg-white p-4 ring-1 ring-slate-200 hover:ring-primary/50">
              <div className="min-w-0">
                <div className="font-bold">{room.isGroup ? "👥 " : "💬 "}{title}</div>
                <div className="truncate text-sm text-slate-500">{lm ? lm.message || "📎 مرفق" : sub}</div>
              </div>
              <div className="whitespace-nowrap text-[11px] text-slate-400">{lm ? fmtDateTime(lm.createdAt) : ""}</div>
            </Link>
          ))}
        </div>
      )}
    </div>
  );
}
