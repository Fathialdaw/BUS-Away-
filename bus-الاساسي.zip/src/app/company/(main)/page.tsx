import Link from "next/link";
import { and, asc, desc, eq, gte, inArray } from "drizzle-orm";
import { db } from "@/db";
import { bookings, passengers, payments, trips } from "@/db/schema";
import { ConfirmButton } from "@/components/client";
import { Card, Empty, Flash, PageTitle, StatCard, StatusBadge, btnCls } from "@/components/ui";
import { can, isManager, requireCompany } from "@/lib/auth";
import { releaseExpired } from "@/lib/booking";
import { fmtDate, fmtDateTime, fmtTime, money, todayStr, tripStatus } from "@/lib/format";
import { getStats } from "@/lib/reports";
import { getSettings } from "@/lib/settings";
import { clearTripsBookingsCompanyAction, resetCompanyDemoAction } from "@/app/company/actions";

export const metadata = { title: "لوحة التحكم" };

export default async function CompanyDashboard({ searchParams }: { searchParams: Promise<Record<string, string | string[] | undefined>> }) {
  const sp = await searchParams;
  const { user, company } = await requireCompany();
  await releaseExpired();
  const s = await getSettings();
  const st = await getStats(company.id);
  const pending = can(user, "payments")
    ? await db
        .select({ p: payments, b: bookings, pax: passengers })
        .from(payments)
        .innerJoin(bookings, eq(bookings.id, payments.bookingId))
        .innerJoin(passengers, eq(passengers.id, bookings.passengerId))
        .where(and(eq(bookings.companyId, company.id), eq(payments.status, "under_review")))
        .orderBy(desc(payments.id))
        .limit(6)
    : [];
  const upcoming = can(user, "trips")
    ? await db
        .select()
        .from(trips)
        .where(and(eq(trips.companyId, company.id), gte(trips.departureDate, todayStr()), inArray(trips.status, ["open", "full", "scheduled", "postponed"])))
        .orderBy(asc(trips.departureDate), asc(trips.departureTime))
        .limit(6)
    : [];
  return (
    <div>
      <Flash sp={sp} />
      <PageTitle title={`مرحباً ${user.name}`} subtitle={`ملخص نشاط ${company.name}`} />
      <div className="grid grid-cols-2 gap-3 md:grid-cols-3 xl:grid-cols-4">
        <StatCard icon="🚌" label="عدد الرحلات" value={st.trips} />
        <StatCard icon="📅" label="الرحلات القادمة" value={st.upcoming} />
        <StatCard icon="🎫" label="عدد الحجوزات" value={st.bookings} />
        <StatCard icon="✅" label="التذاكر المؤكدة" value={st.tickets} />
        <StatCard icon="💺" label="المقاعد المتاحة" value={st.avail} hint="في الرحلات القادمة" />
        <StatCard icon="🧍" label="المقاعد المحجوزة" value={st.booked} hint="في الرحلات القادمة" />
        <StatCard icon="💰" label="المبالغ المحصلة" value={money(st.collected, s.currency)} />
        <StatCard icon="⏳" label="تحويلات قيد المراجعة" value={st.pending} />
      </div>
      <div className="mt-6 grid gap-4 lg:grid-cols-2">
        {can(user, "payments") && (
          <Card>
            <div className="mb-3 flex items-center justify-between">
              <h2 className="text-sm font-bold">تحويلات بانتظار المراجعة</h2>
              <Link href="/company/bookings?status=awaiting_payment" className="text-xs font-semibold text-primary">عرض الكل</Link>
            </div>
            {pending.length === 0 ? (
              <Empty text="لا توجد تحويلات معلقة" icon="✅" />
            ) : (
              <div className="divide-y divide-slate-100">
                {pending.map(({ p, b, pax }) => (
                  <Link key={p.id} href={`/company/bookings/${b.id}`} className="flex items-center justify-between py-2.5 text-sm hover:bg-slate-50">
                    <div>
                      <div className="font-semibold">{pax.name}</div>
                      <div className="text-xs text-slate-500">{b.bookingNumber} • {p.paymentMethod}</div>
                    </div>
                    <div className="text-left">
                      <div className="font-bold text-primary">{money(p.amount, s.currency)}</div>
                      <div className="text-[10px] text-slate-400">{fmtDateTime(p.createdAt)}</div>
                    </div>
                  </Link>
                ))}
              </div>
            )}
          </Card>
        )}
        {can(user, "trips") && (
          <Card>
            <div className="mb-3 flex items-center justify-between">
              <h2 className="text-sm font-bold">الرحلات القادمة</h2>
              <Link href="/company/trips" className="text-xs font-semibold text-primary">عرض الكل</Link>
            </div>
            {upcoming.length === 0 ? (
              <Empty text="لا توجد رحلات قادمة" icon="🚌" />
            ) : (
              <div className="divide-y divide-slate-100">
                {upcoming.map((t) => (
                  <div key={t.id} className="flex items-center justify-between py-2.5 text-sm">
                    <div>
                      <div className="font-semibold">{t.fromCity} ← {t.toCity}</div>
                      <div className="text-xs text-slate-500">{fmtDate(t.departureDate)} • {fmtTime(t.departureTime)}</div>
                    </div>
                    <div className="text-left">
                      <StatusBadge map={tripStatus} value={t.status} />
                      <div className="mt-1 text-[11px] text-slate-500">{t.totalSeats - t.availableSeats}/{t.totalSeats} مقعد</div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </Card>
        )}
      </div>
      {isManager(user) && (
        <Card className="mt-6">
          <h2 className="text-sm font-bold text-amber-700">⚠️ تهيئة بيانات العرض (لأغراض العرض)</h2>
          <p className="mt-2 text-xs leading-6 text-slate-500">
            تحذف جميع حجوزات {company.name} ومدفوعاتها وتذاكراتها ومصروفاتها، وتعيد رحلاتك الكاملة إلى «مفتوحة للحجز» مع فتح جميع
            المقاعد. لا يؤثر هذا الإجراء على بيانات الشركات الأخرى.
          </p>
          <div className="mt-3 flex flex-wrap gap-2">
            <form action={clearTripsBookingsCompanyAction}>
              <ConfirmButton
                message={`هل أنت متأكد؟ ستُحذف جميع رحلات ${company.name} وحجوزاتها ومدفوعاتها وتذاكرها نهائياً. لا يمكن التراجع.`}
                className={btnCls("danger")}
              >
                حذف رحلاتي وحجوزاتي
              </ConfirmButton>
            </form>
            <form action={resetCompanyDemoAction}>
              <ConfirmButton
                message={`هل أنت متأكد؟ ستُحذف كل حجوزات ${company.name} الحالية وتُفتح جميع مقاعد رحلاتها. لا يمكن التراجع.`}
                className={btnCls("warn")}
              >
                تهيئة بيانات العرض (حجوزات رحلاتي)
              </ConfirmButton>
            </form>
          </div>
        </Card>
      )}
    </div>
  );
}
