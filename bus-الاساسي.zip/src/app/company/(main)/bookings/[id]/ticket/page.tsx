import Link from "next/link";
import { notFound } from "next/navigation";
import { PrintButton } from "@/components/client";
import { TicketView } from "@/components/ticket";
import { can, requireCompany } from "@/lib/auth";
import { getTicketData } from "@/lib/booking";
import { getSettings } from "@/lib/settings";

export const metadata = { title: "التذكرة" };

export default async function CompanyTicket({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const { user, company } = await requireCompany();
  if (!can(user, "bookings") && !can(user, "payments") && !can(user, "scan")) notFound();
  const s = await getSettings();
  const d = await getTicketData(Number(id));
  if (!d || d.booking.companyId !== company.id) notFound();
  return (
    <div className="space-y-4">
      <Link href={`/company/bookings/${id}`} className="no-print text-sm text-primary">← الحجز</Link>
      <TicketView d={d} s={s} />
      <div className="no-print flex justify-center"><PrintButton /></div>
    </div>
  );
}
