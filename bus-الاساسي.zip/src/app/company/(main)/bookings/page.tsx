import Link from "next/link";
import { redirect } from "next/navigation";
import { go } from "@/lib/nav";
import { BookingsTable } from "@/components/bookings-table";
import { Flash, PageTitle, btnCls, cx, inputCls } from "@/components/ui";
import { can, requireCompany } from "@/lib/auth";
import { releaseExpired } from "@/lib/booking";
import { listBookings } from "@/lib/bookings-list";
import { bookingStatus, one } from "@/lib/format";
import { getSettings } from "@/lib/settings";

export const metadata = { title: "الحجوزات" };

export default async function CompanyBookings({ searchParams }: { searchParams: Promise<Record<string, string | string[] | undefined>> }) {
  const sp = await searchParams;
  const { user, company } = await requireCompany();
  if (!can(user, "bookings") && !can(user, "payments")) go("/company", { error: "لا تملك صلاحية عرض الحجوزات" });
  await releaseExpired();
  const s = await getSettings();
  const status = one(sp.status);
  const q = one(sp.q);
  const rows = await listBookings({ companyId: company.id, status, q });
  return (
    <div className="space-y-4">
      <PageTitle title="الحجوزات" subtitle={`${rows.length} حجز`} />
      <Flash sp={sp} />
      <div className="flex flex-wrap gap-2">
        <Link href="/company/bookings" className={cx("rounded-full px-3 py-1.5 text-xs font-semibold", !status ? "bg-primary text-white" : "bg-white ring-1 ring-slate-200")}>الكل</Link>
        {Object.entries(bookingStatus).map(([k, v]) => (
          <Link key={k} href={`/company/bookings?status=${k}`} className={cx("rounded-full px-3 py-1.5 text-xs font-semibold", status === k ? "bg-primary text-white" : "bg-white ring-1 ring-slate-200")}>
            {v.label}
          </Link>
        ))}
      </div>
      <form className="flex gap-2">
        {status && <input type="hidden" name="status" value={status} />}
        <input name="q" defaultValue={q} placeholder="بحث برقم الحجز / اسم الراكب / الهاتف / رقم العملية" className={inputCls} />
        <button className={btnCls()}>بحث</button>
      </form>
      <BookingsTable rows={rows} currency={s.currency} base="/company/bookings" />
    </div>
  );
}
