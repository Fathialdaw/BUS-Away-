import { redirect } from "next/navigation";
import { go } from "@/lib/nav";
import { eq, sql } from "drizzle-orm";
import { db } from "@/db";
import { bookings, passengers, tickets, trips } from "@/db/schema";
import { Scanner } from "@/components/client";
import { Card, Flash, PageTitle, Row, StatusBadge, btnCls, inputCls } from "@/components/ui";
import { can, requireCompany } from "@/lib/auth";
import { bookingStatus, fmtDate, fmtDateTime, fmtTime, one, ticketStatus } from "@/lib/format";
import { scanAction } from "@/app/company/actions";

export const metadata = { title: "فحص التذاكر" };

export default async function ScanPage({ searchParams }: { searchParams: Promise<Record<string, string | string[] | undefined>> }) {
  const sp = await searchParams;
  const { user, company } = await requireCompany();
  if (!can(user, "scan")) go("/company", { error: "لا تملك صلاحية فحص التذاكر" });
  const code = one(sp.code).trim();
  const found = code
    ? (
        await db
          .select({ k: tickets, b: bookings, p: passengers, t: trips })
          .from(tickets)
          .innerJoin(bookings, eq(bookings.id, tickets.bookingId))
          .innerJoin(passengers, eq(passengers.id, bookings.passengerId))
          .innerJoin(trips, eq(trips.id, bookings.tripId))
          .where(sql`${tickets.ticketNumber} = ${code} or ${tickets.barcode} = ${code}`)
      )[0]
    : null;
  const foreign = found && found.b.companyId !== company.id;
  return (
    <div className="max-w-2xl space-y-4">
      <PageTitle title="فحص التذاكر والباركود" subtitle="امسح رمز QR أو أدخل رقم التذكرة عند صعود الراكب" />
      <Flash sp={sp} />
      <Card className="space-y-3">
        <form className="flex gap-2">
          <input name="code" defaultValue={code} placeholder="رقم التذكرة، مثال: TK-12345678" dir="ltr" className={inputCls} autoFocus />
          <button className={btnCls()}>بحث</button>
        </form>
        <Scanner />
      </Card>
      {code && !found && <div className="rounded-xl bg-red-50 p-3 text-sm text-red-700">❌ لا توجد تذكرة بهذا الرقم</div>}
      {foreign && <div className="rounded-xl bg-red-50 p-3 text-sm text-red-700">⛔ هذه التذكرة تابعة لشركة أخرى</div>}
      {found && !foreign && (
        <Card>
          <div className="mb-2 flex items-center justify-between">
            <h2 className="font-bold">{found.p.name}</h2>
            <StatusBadge map={ticketStatus} value={found.k.status} />
          </div>
          <Row k="رقم الراكب" v={found.p.passengerNumber} />
          <Row k="رقم التذكرة" v={found.k.ticketNumber} />
          <Row k="الرحلة" v={`${found.t.fromCity} ← ${found.t.toCity}`} />
          <Row k="الموعد" v={`${fmtDate(found.t.departureDate)} - ${fmtTime(found.t.departureTime)}`} />
          <Row k="المقعد" v={<b className="text-xl text-primary">{found.b.seatNumber}</b>} />
          <Row k="حالة الحجز" v={<StatusBadge map={bookingStatus} value={found.b.status} />} />
          {found.k.checkedAt && <Row k="وقت الصعود" v={fmtDateTime(found.k.checkedAt)} />}
          {["confirmed", "issued"].includes(found.k.status) ? (
            <form action={scanAction} className="mt-4">
              <input type="hidden" name="code" value={found.k.ticketNumber} />
              <button className={`${btnCls("success")} w-full py-3 text-base`}>✔ تأكيد صعود الراكب</button>
            </form>
          ) : (
            <div className="mt-4 rounded-xl bg-slate-100 p-3 text-center text-sm text-slate-600">هذه التذكرة غير صالحة للصعود</div>
          )}
        </Card>
      )}
    </div>
  );
}
