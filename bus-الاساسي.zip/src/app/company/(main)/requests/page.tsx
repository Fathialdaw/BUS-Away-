import { redirect } from "next/navigation";
import { go } from "@/lib/nav";
import { desc, eq } from "drizzle-orm";
import { db } from "@/db";
import { adminBookingRequests, passengers, trips, users } from "@/db/schema";
import { Card, Empty, Flash, PageTitle, StatusBadge, btnCls } from "@/components/ui";
import { isManager, requireCompany } from "@/lib/auth";
import { fmtDate, fmtDateTime, fmtTime, requestStatus } from "@/lib/format";
import { decideRequestAction } from "@/app/company/actions";

export const metadata = { title: "طلبات مدير النظام" };

export default async function RequestsPage({ searchParams }: { searchParams: Promise<Record<string, string | string[] | undefined>> }) {
  const sp = await searchParams;
  const { user, company } = await requireCompany();
  if (!isManager(user)) go("/company", { error: "هذه الصفحة لمدير المكتب فقط" });
  const rows = await db
    .select({ r: adminBookingRequests, t: trips, p: passengers, a: users })
    .from(adminBookingRequests)
    .innerJoin(trips, eq(trips.id, adminBookingRequests.tripId))
    .innerJoin(passengers, eq(passengers.id, adminBookingRequests.passengerId))
    .innerJoin(users, eq(users.id, adminBookingRequests.adminId))
    .where(eq(adminBookingRequests.companyId, company.id))
    .orderBy(desc(adminBookingRequests.id));
  return (
    <div className="space-y-4">
      <PageTitle title="طلبات حجز من مدير النظام" subtitle="لا يستطيع مدير النظام الحجز باسم شركتك إلا بعد موافقتك" />
      <Flash sp={sp} />
      {rows.length === 0 ? (
        <Empty text="لا توجد طلبات" icon="📨" />
      ) : (
        <div className="grid gap-3 md:grid-cols-2">
          {rows.map(({ r, t, p, a }) => (
            <Card key={r.id}>
              <div className="flex items-start justify-between">
                <div className="font-bold">{t.fromCity} ← {t.toCity}</div>
                <StatusBadge map={requestStatus} value={r.status} />
              </div>
              <div className="mt-2 space-y-1 text-sm text-slate-600">
                <div>📅 {fmtDate(t.departureDate)} • {fmtTime(t.departureTime)}</div>
                <div>🧍 الراكب: {p.name} ({p.passengerNumber})</div>
                <div>💺 المقعد المطلوب: <b>{r.seatNumber}</b></div>
                <div>👤 الطالب: {a.name} • {fmtDateTime(r.createdAt)}</div>
                {r.note && <div>📝 {r.note}</div>}
              </div>
              {r.status === "pending" && (
                <form action={decideRequestAction} className="mt-3 flex gap-2">
                  <input type="hidden" name="id" value={r.id} />
                  <button name="decision" value="approve" className={btnCls("success", true)}>موافقة</button>
                  <button name="decision" value="reject" className={btnCls("danger", true)}>رفض</button>
                </form>
              )}
            </Card>
          ))}
        </div>
      )}
    </div>
  );
}
