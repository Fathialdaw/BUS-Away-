import { redirect } from "next/navigation";
import { go } from "@/lib/nav";
import { ReportView } from "@/components/charts";
import { PageTitle } from "@/components/ui";
import { isManager, requireCompany } from "@/lib/auth";
import { getReport } from "@/lib/reports";
import { getSettings } from "@/lib/settings";

export const metadata = { title: "التقارير والرسوم البيانية" };

export default async function CompanyReports() {
  const { user, company } = await requireCompany();
  if (!isManager(user)) go("/company", { error: "هذه الصفحة لمدير المكتب فقط" });
  const s = await getSettings();
  const r = await getReport(company.id);
  return (
    <div>
      <PageTitle title="التقارير والرسوم البيانية" subtitle={`أداء ${company.name}`} />
      <ReportView r={r} currency={s.currency} />
    </div>
  );
}
