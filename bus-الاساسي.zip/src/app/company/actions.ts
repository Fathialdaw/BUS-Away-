"use server";

import { and, desc, eq, inArray, or, sql } from "drizzle-orm";
import { db } from "@/db";
import {
  adminBookingRequests,
  bookings,
  chatMembers,
  chatRooms,
  companies,
  companyAccounts,
  expenses,
  messages,
  payments,
  trips,
  tripSeats,
  users,
} from "@/db/schema";
import {
  can,
  clearSession,
  hashPassword,
  requireCompany,
  setSession,
  verifyPassword,
  isManager,
  type Company,
  type StaffUser,
} from "@/lib/auth";
import {
  audit,
  cancelBooking,
  cancelTrip,
  changeSeat,
  checkInTicket,
  issueTicket,
  notifyPassenger,
  notifyTripTimeChanged,
  reviewPayment,
  syncSeats,
  tplNotify,
  loadBooking,
  ACTIVE,
  type Actor,
} from "@/lib/booking";
import { PERMS, digits, num, str } from "@/lib/format";
import { go } from "@/lib/nav";
import { normPhone } from "@/lib/otp";
import { clearTripsAndBookingsCompany, reseedCompany } from "@/lib/reseed";
import { getSettings } from "@/lib/settings";

const actorOf = (u: StaffUser, c: Company): Actor => ({
  userId: u.id,
  name: u.name,
  type: u.role === "company_manager" ? "manager" : "employee",
  companyId: c.id,
});

function deny(path = "/company"): never {
  go(path, { error: "لا تملك صلاحية تنفيذ هذا الإجراء" });
}

export async function companyLoginAction(fd: FormData): Promise<void> {
  const id = str(fd.get("identifier"));
  const pw = str(fd.get("password"));
  const L = "/company/login";
  const [u] = await db
    .select()
    .from(users)
    .where(or(eq(users.email, id.toLowerCase()), eq(users.phone, normPhone(id))));
  if (!u || !verifyPassword(pw, u.password) || !u.companyId || u.role === "system_admin")
    go(L, { error: "بيانات الدخول غير صحيحة" });
  if (u.status !== "active") go(L, { error: "هذا الحساب معطل" });
  const [c] = await db.select().from(companies).where(eq(companies.id, u.companyId));
  if (!c || c.status === "suspended") go(L, { error: "حساب الشركة موقوف، تواصل مع مدير النظام" });
  await setSession("company", u.id);
  await db.update(users).set({ lastLoginAt: new Date() }).where(eq(users.id, u.id));
  await audit(actorOf(u, c), "login", "user", u.id);
  go("/company");
}

export async function companyLogoutAction(): Promise<void> {
  await clearSession("company");
  go("/company/login");
}

/* ---------- الحجوزات والمدفوعات ---------- */

export async function reviewPaymentAction(fd: FormData): Promise<void> {
  const { user, company } = await requireCompany();
  const bookingId = Number(str(fd.get("bookingId")));
  const back = `/company/bookings/${bookingId}`;
  if (!can(user, "payments")) deny(back);
  const action = str(fd.get("action")) as "accept" | "reject" | "needs_edit";
  const note = str(fd.get("note"));
  if (action !== "accept" && !note && action === "needs_edit") go(back, { error: "اكتب ملاحظة للراكب لتوضيح التعديل المطلوب" });
  const r = await reviewPayment(Number(str(fd.get("paymentId"))), action, actorOf(user, company), note, company.id);
  go(back, r.error ? { error: r.error } : { ok: "تم تنفيذ الإجراء وإشعار الراكب" });
}

export async function cancelBookingByCompanyAction(fd: FormData): Promise<void> {
  const { user, company } = await requireCompany();
  const id = Number(str(fd.get("bookingId")));
  const back = `/company/bookings/${id}`;
  if (!can(user, "payments")) deny(back);
  const r = await cancelBooking(id, actorOf(user, company), str(fd.get("reason")), company.id);
  go(back, r.error ? { error: r.error } : { ok: "تم إلغاء الحجز" });
}

export async function changeSeatAction(fd: FormData): Promise<void> {
  const { user, company } = await requireCompany();
  const id = Number(str(fd.get("bookingId")));
  const back = `/company/bookings/${id}`;
  if (!can(user, "payments")) deny(back);
  const r = await changeSeat(id, Number(str(fd.get("seat"))), actorOf(user, company), company.id);
  go(back, r.error ? { error: r.error } : { ok: "تم تغيير المقعد وإشعار الراكب" });
}

export async function sendNotificationAction(fd: FormData): Promise<void> {
  const { user, company } = await requireCompany();
  const id = Number(str(fd.get("bookingId")));
  const back = `/company/bookings/${id}`;
  if (!can(user, "bookings")) deny(back);
  const tb = await loadBooking(id);
  if (!tb || tb.booking.companyId !== company.id) go(back, { error: "الحجز غير موجود" });
  const msg = str(fd.get("message"));
  if (!msg) go(back, { error: "اكتب نص الرسالة" });
  await notifyPassenger(tb.booking.passengerId, "info", `رسالة من ${company.name}`, msg);
  await audit(actorOf(user, company), "notify_passenger", "booking", id, null, { msg });
  go(back, { ok: "تم إرسال الإشعار للراكب" });
}

export async function markNoShowAction(fd: FormData): Promise<void> {
  const { user, company } = await requireCompany();
  const id = Number(str(fd.get("bookingId")));
  const back = `/company/bookings/${id}`;
  if (!can(user, "scan")) deny(back);
  const tb = await loadBooking(id);
  if (!tb || tb.booking.companyId !== company.id || tb.booking.status !== "confirmed") go(back, { error: "لا يمكن تنفيذ الإجراء" });
  await db.update(bookings).set({ status: "no_show" }).where(eq(bookings.id, id));
  await db.execute(sql`update tickets set status = 'no_show' where booking_id = ${id}`);
  await audit(actorOf(user, company), "no_show", "booking", id);
  go(back, { ok: "تم تسجيل عدم حضور الراكب" });
}

export async function scanAction(fd: FormData): Promise<void> {
  const { user, company } = await requireCompany();
  if (!can(user, "scan")) deny();
  const code = str(fd.get("code"));
  const r = await checkInTicket(code, actorOf(user, company), company.id);
  go(`/company/scan?code=${encodeURIComponent(code)}`, "error" in r ? { error: r.error } : { ok: r.ok });
}

/* ---------- إدارة مقاعد الرحلة ---------- */

async function ensureSeatRows(tripId: number, total: number) {
  const existing = await db.select({ s: tripSeats.seatNumber }).from(tripSeats).where(eq(tripSeats.tripId, tripId));
  const have = new Set(existing.map((r) => r.s));
  const toAdd: { tripId: number; seatNumber: number; status: string }[] = [];
  for (let n = 1; n <= total; n++) if (!have.has(n)) toAdd.push({ tripId, seatNumber: n, status: "blocked" });
  if (toAdd.length) await db.insert(tripSeats).values(toAdd);
  if (existing.some((r) => r.s > total))
    await db.delete(tripSeats).where(and(eq(tripSeats.tripId, tripId), sql`${tripSeats.seatNumber} > ${total}`));
}

/** فتح/حظر مقعد واحد: مدير الشركة أو موظف بصلاحية الرحلات */
export async function toggleTripSeatAction(fd: FormData): Promise<void> {
  const { user, company } = await requireCompany();
  if (!isManager(user) && !can(user, "trips")) deny();
  const tripId = Number(str(fd.get("tripId")));
  const seat = Number(str(fd.get("seat")));
  const [t] = await db.select().from(trips).where(and(eq(trips.id, tripId), eq(trips.companyId, company.id)));
  if (!t || !Number.isInteger(seat) || seat < 1 || seat > t.totalSeats) deny(`/company/trips/${tripId}/seats`);
  const [r] = await db
    .select()
    .from(tripSeats)
    .where(and(eq(tripSeats.tripId, tripId), eq(tripSeats.seatNumber, seat)));
  const next = r?.status === "open" ? "blocked" : "open";
  if (r) await db.update(tripSeats).set({ status: next, updatedBy: user.id, updatedAt: new Date() }).where(eq(tripSeats.id, r.id));
  else await db.insert(tripSeats).values({ tripId, seatNumber: seat, status: next, updatedBy: user.id });
  await syncSeats(tripId);
  await audit(actorOf(user, company), "toggle_seat", "trip_seat", `${tripId}:${seat}`, { status: r?.status ?? null }, { status: next });
  go(`/company/trips/${tripId}/seats`, { ok: next === "open" ? `تم فتح المقعد ${seat} للحجز` : `تم حظر المقعد ${seat}` });
}

/** فتح أو حظر جميع المقاعد دفعة واحدة */
export async function bulkTripSeatsAction(fd: FormData): Promise<void> {
  const { user, company } = await requireCompany();
  if (!isManager(user) && !can(user, "trips")) deny();
  const tripId = Number(str(fd.get("tripId")));
  const status = str(fd.get("status")) === "open" ? "open" : "blocked";
  const [t] = await db.select().from(trips).where(and(eq(trips.id, tripId), eq(trips.companyId, company.id)));
  if (!t) deny("/company/trips");
  await db
    .insert(tripSeats)
    .values(Array.from({ length: t.totalSeats }, (_, i) => ({ tripId, seatNumber: i + 1, status, updatedBy: user.id })))
    .onConflictDoUpdate({ target: [tripSeats.tripId, tripSeats.seatNumber], set: { status, updatedBy: user.id, updatedAt: new Date() } });
  await syncSeats(tripId);
  await audit(actorOf(user, company), status === "open" ? "open_all_seats" : "block_all_seats", "trip", tripId, null, { seats: t.totalSeats });
  go(`/company/trips/${tripId}/seats`, { ok: status === "open" ? "تم فتح جميع المقاعد" : "تم حظر جميع المقاعد" });
}

/* ---------- الرحلات ---------- */

export async function saveTripAction(fd: FormData): Promise<void> {
  const { user, company } = await requireCompany();
  if (!isManager(user)) deny("/company/trips");
  const id = Number(str(fd.get("id"))) || 0;
  const back = id ? `/company/trips/${id}` : "/company/trips/new";
  const v = {
    fromState: str(fd.get("fromState")),
    fromCity: str(fd.get("fromCity")),
    toState: str(fd.get("toState")),
    toCity: str(fd.get("toCity")),
    meetingPoint: str(fd.get("meetingPoint")) || null,
    mapUrl: str(fd.get("mapUrl")) || null,
    departureDate: str(fd.get("departureDate")),
    departureTime: str(fd.get("departureTime")),
    arrivalTime: str(fd.get("arrivalTime")) || null,
    busType: str(fd.get("busType")) || "عادي",
    totalSeats: num(fd.get("totalSeats")),
    price: num(fd.get("price")),
    status: str(fd.get("status")) || "open",
    notes: str(fd.get("notes")) || null,
  };
  if (!v.fromCity || !v.toCity || !v.fromState || !v.toState) go(back, { error: "حدد نقطة الانطلاق والوجهة" });
  if (!v.departureDate || !v.departureTime) go(back, { error: "حدد تاريخ ووقت المغادرة" });
  if (v.totalSeats < 1 || v.totalSeats > 100) go(back, { error: "عدد المقاعد بين 1 و 100" });
  if (v.price < 0) go(back, { error: "السعر غير صحيح" });
  const actor = actorOf(user, company);
  if (!id) {
    const [t] = await db
      .insert(trips)
      .values({ ...v, companyId: company.id, availableSeats: 0 })
      .returning();
    await ensureSeatRows(t.id, v.totalSeats);
    await audit(actor, "create_trip", "trip", t.id, null, v);
    go(`/company/trips/${t.id}/seats`, { ok: "تمت إضافة الرحلة — افتح المقاعد التي تريد بيعها عبر التطبيق" });
  }
  const [old] = await db.select().from(trips).where(and(eq(trips.id, id), eq(trips.companyId, company.id)));
  if (!old) go("/company/trips", { error: "الرحلة غير موجودة" });
  const [{ mx }] = await db
    .select({ mx: sql<number>`coalesce(max(${bookings.seatNumber}),0)` })
    .from(bookings)
    .where(and(eq(bookings.tripId, id), inArray(bookings.status, ACTIVE)));
  if (v.totalSeats < Number(mx)) go(back, { error: `لا يمكن تقليل المقاعد عن ${mx} لوجود حجوزات` });
  const becameCancelled = v.status === "cancelled" && old.status !== "cancelled";
  await db
    .update(trips)
    .set({ ...v, status: becameCancelled ? old.status : v.status })
    .where(and(eq(trips.id, id), eq(trips.companyId, company.id)));
  if (old.totalSeats !== v.totalSeats) await ensureSeatRows(id, v.totalSeats);
  if (becameCancelled) await cancelTrip(id, actor);
  else {
    await syncSeats(id);
    if (old.departureDate !== v.departureDate || old.departureTime !== v.departureTime) await notifyTripTimeChanged(id);
  }
  await audit(actor, "update_trip", "trip", id, old, v);
  go("/company/trips", { ok: "تم حفظ تعديلات الرحلة" });
}

export async function cancelTripAction(fd: FormData): Promise<void> {
  const { user, company } = await requireCompany();
  if (!isManager(user)) deny("/company/trips");
  const id = Number(str(fd.get("id")));
  const [t] = await db.select().from(trips).where(and(eq(trips.id, id), eq(trips.companyId, company.id)));
  if (!t) go("/company/trips", { error: "الرحلة غير موجودة" });
  await cancelTrip(id, actorOf(user, company));
  go("/company/trips", { ok: "تم إلغاء الرحلة وإشعار الركاب" });
}

export async function deleteTripAction(fd: FormData): Promise<void> {
  const { user, company } = await requireCompany();
  if (!isManager(user)) deny("/company/trips");
  const id = Number(str(fd.get("id")));
  const [t] = await db.select().from(trips).where(and(eq(trips.id, id), eq(trips.companyId, company.id)));
  if (!t) go("/company/trips", { error: "الرحلة غير موجودة" });
  const bs = await db.select({ id: bookings.id }).from(bookings).where(eq(bookings.tripId, id)).limit(1);
  if (bs.length) go("/company/trips", { error: "لا يمكن حذف رحلة لها حجوزات، يمكنك إلغاؤها بدلاً من ذلك" });
  await db.update(expenses).set({ tripId: null }).where(eq(expenses.tripId, id));
  await db.execute(sql`delete from admin_booking_requests where trip_id = ${id}`);
  await db.delete(trips).where(eq(trips.id, id));
  await audit(actorOf(user, company), "delete_trip", "trip", id, t, null);
  go("/company/trips", { ok: "تم حذف الرحلة" });
}

/* ---------- حسابات الدفع ---------- */

export async function saveAccountAction(fd: FormData): Promise<void> {
  const { user, company } = await requireCompany();
  if (!isManager(user)) deny("/company/accounts");
  const id = Number(str(fd.get("id"))) || 0;
  const v = {
    paymentType: str(fd.get("paymentType")),
    accountName: str(fd.get("accountName")),
    accountNumber: str(fd.get("accountNumber")),
    bankName: str(fd.get("bankName")) || null,
  };
  if (!v.paymentType || !v.accountName || !v.accountNumber) go("/company/accounts", { error: "أكمل بيانات الحساب" });
  if (id) {
    await db.update(companyAccounts).set(v).where(and(eq(companyAccounts.id, id), eq(companyAccounts.companyId, company.id)));
  } else {
    await db.insert(companyAccounts).values({ ...v, companyId: company.id });
  }
  await audit(actorOf(user, company), id ? "update_account" : "create_account", "company_account", id || null, null, v);
  go("/company/accounts", { ok: "تم حفظ حساب الدفع" });
}

export async function toggleAccountAction(fd: FormData): Promise<void> {
  const { user, company } = await requireCompany();
  if (!isManager(user)) deny("/company/accounts");
  const id = Number(str(fd.get("id")));
  await db
    .update(companyAccounts)
    .set({ status: sql`case when ${companyAccounts.status} = 'active' then 'disabled' else 'active' end` })
    .where(and(eq(companyAccounts.id, id), eq(companyAccounts.companyId, company.id)));
  await audit(actorOf(user, company), "toggle_account", "company_account", id);
  go("/company/accounts", { ok: "تم تحديث حالة الحساب" });
}

export async function deleteAccountAction(fd: FormData): Promise<void> {
  const { user, company } = await requireCompany();
  if (!isManager(user)) deny("/company/accounts");
  const id = Number(str(fd.get("id")));
  const used = await db.select({ id: payments.id }).from(payments).where(eq(payments.companyAccountId, id)).limit(1);
  if (used.length) go("/company/accounts", { error: "الحساب مستخدم في عمليات دفع سابقة، قم بتعطيله بدلاً من حذفه" });
  await db.delete(companyAccounts).where(and(eq(companyAccounts.id, id), eq(companyAccounts.companyId, company.id)));
  await audit(actorOf(user, company), "delete_account", "company_account", id);
  go("/company/accounts", { ok: "تم حذف الحساب" });
}

/* ---------- الموظفون ---------- */

function permsFrom(fd: FormData): string[] {
  const keys = PERMS.map((p) => p.key);
  return fd.getAll("perms").map(String).filter((k) => keys.includes(k));
}

export async function addStaffAction(fd: FormData): Promise<void> {
  const { user, company } = await requireCompany();
  if (!isManager(user)) deny("/company/staff");
  const name = str(fd.get("name"));
  const phone = normPhone(str(fd.get("phone")));
  const email = str(fd.get("email")).toLowerCase() || null;
  const pw = str(fd.get("password"));
  if (!name || !phone || pw.length < 6) go("/company/staff", { error: "أكمل الاسم والهاتف وكلمة مرور (6 أحرف على الأقل)" });
  const dup = await db.select({ id: users.id }).from(users).where(email ? or(eq(users.phone, phone), eq(users.email, email)) : eq(users.phone, phone));
  if (dup.length) go("/company/staff", { error: "الهاتف أو البريد مستخدم لحساب آخر" });
  const [u] = await db
    .insert(users)
    .values({ name, phone, email, password: hashPassword(pw), role: "employee", companyId: company.id, permissions: permsFrom(fd) })
    .returning();
  await audit(actorOf(user, company), "create_employee", "user", u.id, null, { name, phone });
  go("/company/staff", { ok: "تمت إضافة الموظف" });
}

export async function updateStaffAction(fd: FormData): Promise<void> {
  const { user, company } = await requireCompany();
  if (!isManager(user)) deny("/company/staff");
  const id = Number(str(fd.get("id")));
  const status = str(fd.get("status")) === "disabled" ? "disabled" : "active";
  const pw = str(fd.get("password"));
  const set: Partial<typeof users.$inferInsert> = { status, permissions: permsFrom(fd) };
  if (pw) {
    if (pw.length < 6) go("/company/staff", { error: "كلمة المرور قصيرة" });
    set.password = hashPassword(pw);
  }
  // الموظف يجب أن يكون تابعاً لنفس الشركة
  await db.update(users).set(set).where(and(eq(users.id, id), eq(users.companyId, company.id), eq(users.role, "employee")));
  await audit(actorOf(user, company), "update_employee", "user", id, null, { status, permissions: set.permissions });
  go("/company/staff", { ok: "تم تحديث بيانات الموظف" });
}

/* ---------- المصروفات ---------- */

export async function addExpenseAction(fd: FormData): Promise<void> {
  const { user, company } = await requireCompany();
  if (!isManager(user)) deny();
  const title = str(fd.get("title"));
  const amount = num(fd.get("amount"));
  const tripId = Number(str(fd.get("tripId"))) || null;
  if (!title || amount <= 0) go("/company/expenses", { error: "أدخل بيان المصروف والمبلغ" });
  if (tripId) {
    const [t] = await db.select().from(trips).where(and(eq(trips.id, tripId), eq(trips.companyId, company.id)));
    if (!t) go("/company/expenses", { error: "الرحلة غير صحيحة" });
  }
  await db.insert(expenses).values({
    companyId: company.id,
    title,
    amount,
    tripId,
    expenseDate: str(fd.get("date")) || new Date().toISOString().slice(0, 10),
    createdBy: user.id,
  });
  await audit(actorOf(user, company), "create_expense", "expense", null, null, { title, amount });
  go("/company/expenses", { ok: "تم تسجيل المصروف" });
}

export async function deleteExpenseAction(fd: FormData): Promise<void> {
  const { user, company } = await requireCompany();
  if (!isManager(user)) deny();
  const id = Number(str(fd.get("id")));
  await db.delete(expenses).where(and(eq(expenses.id, id), eq(expenses.companyId, company.id)));
  await audit(actorOf(user, company), "delete_expense", "expense", id);
  go("/company/expenses", { ok: "تم حذف المصروف" });
}

/* ---------- طلبات مدير النظام ---------- */

export async function decideRequestAction(fd: FormData): Promise<void> {
  const { user, company } = await requireCompany();
  const P = "/company/requests";
  if (!isManager(user)) deny(P);
  const id = Number(str(fd.get("id")));
  const approve = str(fd.get("decision")) === "approve";
  const [r] = await db
    .select()
    .from(adminBookingRequests)
    .where(and(eq(adminBookingRequests.id, id), eq(adminBookingRequests.companyId, company.id), eq(adminBookingRequests.status, "pending")));
  if (!r) go(P, { error: "الطلب غير موجود" });
  const actor = actorOf(user, company);
  if (!approve) {
    await db.update(adminBookingRequests).set({ status: "rejected", decidedBy: user.id, decidedAt: new Date() }).where(eq(adminBookingRequests.id, id));
    await audit(actor, "reject_admin_request", "admin_booking_request", id);
    go(P, { ok: "تم رفض الطلب" });
  }
  const [t] = await db.select().from(trips).where(and(eq(trips.id, r.tripId), eq(trips.companyId, company.id)));
  if (!t || !["open", "full"].includes(t.status)) go(P, { error: "الرحلة غير متاحة للحجز" });
  let booking;
  try {
    [booking] = await db
      .insert(bookings)
      .values({
        bookingNumber: `BK-${new Date().toISOString().slice(0, 10).replace(/-/g, "")}-${digits(5)}`,
        passengerId: r.passengerId,
        tripId: t.id,
        companyId: company.id,
        seatNumber: r.seatNumber,
        price: t.price,
        status: "confirmed",
        source: "admin",
      })
      .returning();
  } catch {
    go(P, { error: "المقعد المطلوب محجوز بالفعل" });
  }
  await db.insert(payments).values({
    bookingId: booking.id,
    paymentMethod: "حجز إداري",
    transactionNumber: `ADM-${id}`,
    amount: t.price,
    status: "accepted",
    reviewedBy: user.id,
    reviewedAt: new Date(),
  });
  await issueTicket(booking.id);
  await syncSeats(t.id);
  const tb = await loadBooking(booking.id);
  if (tb) await tplNotify("tpl_confirmed", tb, {}, `confirmed:${booking.id}`);
  await db
    .update(adminBookingRequests)
    .set({ status: "approved", decidedBy: user.id, decidedAt: new Date(), bookingId: booking.id })
    .where(eq(adminBookingRequests.id, id));
  await audit(actor, "approve_admin_request", "admin_booking_request", id, null, { bookingId: booking.id });
  go(P, { ok: "تمت الموافقة وإنشاء الحجز في نظام الشركة" });
}

/* ---------- بيانات الشركة ---------- */

/** حذف رحلات وحجوزات الشركة — لمدير المكتب فقط وعلى شركته فقط */
export async function clearTripsBookingsCompanyAction(): Promise<void> {
  const { user, company } = await requireCompany();
  if (!isManager(user)) deny("/company");
  await clearTripsAndBookingsCompany(company.id);
  await audit(actorOf(user, company), "clear_trips_bookings", "company", company.id);
  go("/company", { ok: `تم حذف جميع رحلات ${company.name} وحجوزاتها` });
}

/** تهيئة بيانات العرض: لمدير المكتب فقط، ولشركته فقط */
export async function resetCompanyDemoAction(): Promise<void> {
  const { user, company } = await requireCompany();
  if (!isManager(user)) deny("/company");
  await reseedCompany(company.id);
  await audit(actorOf(user, company), "reset_company_demo", "company", company.id);
  go("/company", { ok: "تمت تهيئة بيانات العرض: أُزيلت حجوزات شركتك ومدفوعاتها وتذاكرها، وفُتحت جميع مقاعد رحلاتك." });
}

export async function updateCompanyAction(fd: FormData): Promise<void> {
  const { user, company } = await requireCompany();
  if (!isManager(user)) deny();
  const v = {
    phone: str(fd.get("phone")) || null,
    email: str(fd.get("email")) || null,
    address: str(fd.get("address")) || null,
    routes: str(fd.get("routes")) || null,
  };
  await db.update(companies).set(v).where(eq(companies.id, company.id));
  await audit(actorOf(user, company), "update_company", "company", company.id, null, v);
  go("/company/profile", { ok: "تم حفظ بيانات الشركة" });
}

/** تغيير شعار الشركة: لمدير المكتب فقط وعلى شركته فقط */
export async function updateCompanyLogoAction(fd: FormData): Promise<void> {
  const { user, company } = await requireCompany();
  if (!isManager(user)) deny("/company");
  const logo = str(fd.get("logo"));
  if (logo && !logo.startsWith("/api/files/")) go("/company/profile", { error: "مصدر الصورة غير صالح" });
  await db.update(companies).set({ logo: logo || null }).where(eq(companies.id, company.id));
  await audit(actorOf(user, company), "update_company_logo", "company", company.id, { logo: company.logo }, { logo: logo || null });
  go("/company/profile", { ok: logo ? "تم تغيير شعار الشركة" : "تمت إزالة شعار الشركة" });
}

/* ---------- الدردشة ---------- */

async function chatAllowed(user: StaffUser) {
  if (isManager(user)) return true;
  const s = await getSettings();
  return s.employee_chat_allowed === "true";
}

export async function startDirectChatAction(fd: FormData): Promise<void> {
  const { user } = await requireCompany();
  if (!(await chatAllowed(user))) deny();
  const other = Number(str(fd.get("userId")));
  const [o] = await db.select().from(users).where(and(eq(users.id, other), eq(users.role, "company_manager"), eq(users.status, "active")));
  if (!o || o.id === user.id) go("/company/chat", { error: "المستخدم غير صالح" });
  const key = [user.id, o.id].sort((a, b) => a - b).join("-");
  let [room] = await db.select().from(chatRooms).where(eq(chatRooms.directKey, key));
  if (!room) {
    [room] = await db.insert(chatRooms).values({ isGroup: false, directKey: key, createdBy: user.id }).returning();
    await db.insert(chatMembers).values([{ roomId: room.id, userId: user.id }, { roomId: room.id, userId: o.id }]);
  }
  go(`/company/chat/${room.id}`);
}

export async function createGroupChatAction(fd: FormData): Promise<void> {
  const { user } = await requireCompany();
  if (!(await chatAllowed(user))) deny();
  const name = str(fd.get("name"));
  const ids = fd.getAll("members").map((x) => Number(x)).filter(Boolean);
  if (!name || ids.length < 1) go("/company/chat", { error: "اكتب اسم المجموعة واختر عضواً واحداً على الأقل" });
  const valid = await db.select({ id: users.id }).from(users).where(and(inArray(users.id, ids), eq(users.role, "company_manager"), eq(users.status, "active")));
  const [room] = await db.insert(chatRooms).values({ name, isGroup: true, createdBy: user.id }).returning();
  const members = Array.from(new Set([user.id, ...valid.map((v) => v.id)]));
  await db.insert(chatMembers).values(members.map((userId) => ({ roomId: room.id, userId })));
  go(`/company/chat/${room.id}`);
}

export async function sendMessageAction(fd: FormData): Promise<void> {
  const { user } = await requireCompany();
  const roomId = Number(str(fd.get("roomId")));
  const back = `/company/chat/${roomId}`;
  if (!(await chatAllowed(user))) deny();
  const [m] = await db.select().from(chatMembers).where(and(eq(chatMembers.roomId, roomId), eq(chatMembers.userId, user.id)));
  if (!m) deny("/company/chat");
  const text = str(fd.get("message"));
  const attachment = str(fd.get("attachment")) || null;
  if (!text && !attachment) go(back);
  const [room] = await db.select().from(chatRooms).where(eq(chatRooms.id, roomId));
  let receiverId: number | null = null;
  if (room && !room.isGroup) {
    const others = await db.select().from(chatMembers).where(eq(chatMembers.roomId, roomId));
    receiverId = others.find((o) => o.userId !== user.id)?.userId ?? null;
  }
  await db.insert(messages).values({ roomId, senderId: user.id, receiverId, message: text, attachment });
  go(back);
}

export async function reportMessageAction(fd: FormData): Promise<void> {
  const { user } = await requireCompany();
  const id = Number(str(fd.get("id")));
  const [msg] = await db.select().from(messages).where(eq(messages.id, id));
  if (!msg) go("/company/chat", { error: "الرسالة غير موجودة" });
  const back = `/company/chat/${msg.roomId}`;
  const [m] = await db.select().from(chatMembers).where(and(eq(chatMembers.roomId, msg.roomId), eq(chatMembers.userId, user.id)));
  if (!m) deny("/company/chat");
  await db.update(messages).set({ reported: true, reportReason: str(fd.get("reason")) || "محتوى غير لائق" }).where(eq(messages.id, id));
  go(back, { ok: "تم إرسال البلاغ إلى مدير النظام" });
}

void desc;
