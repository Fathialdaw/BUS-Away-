import type { Metadata, Viewport } from "next";
import type { CSSProperties, ReactNode } from "react";
import { InstallPrompt } from "@/components/client";
import { getSettings } from "@/lib/settings";

export async function generateMetadata(): Promise<Metadata> {
  const s = await getSettings();
  const icon = s.app_icon || "/icons/passenger-192.png";
  return {
    manifest: "/passenger/manifest.webmanifest",
    applicationName: s.app_name,
    appleWebApp: { capable: true, title: s.app_name, statusBarStyle: "default" },
    icons: { icon, apple: icon },
  };
}

export async function generateViewport(): Promise<Viewport> {
  const s = await getSettings();
  return { themeColor: s.primary_color, width: "device-width", initialScale: 1 };
}

export default async function PassengerLayout({ children }: { children: ReactNode }) {
  const s = await getSettings();
  return (
    <div style={{ "--primary": s.primary_color } as CSSProperties} className="min-h-screen">
      <InstallPrompt app="passenger" label="تطبيق المسافر" />
      {children}
    </div>
  );
}
