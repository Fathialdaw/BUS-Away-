import Link from "next/link";
import { AuthShell } from "@/components/auth-shell";
import { Field, Flash, btnCls, inputCls } from "@/components/ui";
import { loginAction, otpLoginRequestAction } from "../../actions";
import { one } from "@/lib/format";

export const metadata = { title: "تسجيل الدخول" };

export default async function LoginPage({ searchParams }: { searchParams: Promise<Record<string, string | string[] | undefined>> }) {
  const sp = await searchParams;
  const otp = one(sp.mode) === "otp";
  const tab = (active: boolean) =>
    `flex-1 rounded-lg py-2 text-center text-sm font-semibold ${active ? "bg-white text-primary shadow" : "text-slate-500"}`;
  return (
    <AuthShell title="تسجيل الدخول" subtitle="أهلاً بك، سجّل دخولك لحجز رحلتك" badge="تطبيق المسافر" returnTo="/passenger/login">
      <Flash sp={sp} />
      <div className="mb-4 flex gap-1 rounded-xl bg-slate-100 p-1">
        <Link href="/passenger/login" className={tab(!otp)}>كلمة المرور</Link>
        <Link href="/passenger/login?mode=otp" className={tab(otp)}>رمز التحقق OTP</Link>
      </div>
      {otp ? (
        <form action={otpLoginRequestAction} className="space-y-4">
          <Field label="رقم الهاتف">
            <input name="phone" required inputMode="tel" placeholder="09XXXXXXXX" className={inputCls} />
          </Field>
          <button className={`${btnCls()} w-full`}>إرسال رمز التحقق</button>
        </form>
      ) : (
        <form action={loginAction} className="space-y-4">
          <Field label="رقم الراكب أو رقم الهاتف">
            <input name="identifier" required placeholder="P100001 أو 09XXXXXXXX" className={inputCls} />
          </Field>
          <Field label="كلمة المرور">
            <input name="password" type="password" required className={inputCls} />
          </Field>
          <button className={`${btnCls()} w-full`}>تسجيل الدخول</button>
        </form>
      )}
      <div className="mt-4 flex items-center justify-between text-sm">
        <Link href="/passenger/forgot" className="text-primary">نسيت كلمة المرور؟</Link>
        <Link href="/passenger/register" className="font-semibold text-primary">إنشاء حساب جديد</Link>
      </div>
      <div className="mt-5 rounded-xl bg-slate-50 p-3 text-xs text-slate-500">
        حساب تجريبي: <b dir="ltr">0912345678</b> / كلمة المرور <b dir="ltr">pass123</b>
      </div>
    </AuthShell>
  );
}
