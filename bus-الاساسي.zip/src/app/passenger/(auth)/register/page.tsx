import Link from "next/link";
import { AuthShell } from "@/components/auth-shell";
import { StateSelect, CityList } from "@/components/geo-select";
import { FileUpload } from "@/components/client";
import { Field, Flash, btnCls, inputCls } from "@/components/ui";
import { getGeo } from "@/lib/trips";
import { registerAction } from "../../actions";

export const metadata = { title: "إنشاء حساب" };

export default async function RegisterPage({ searchParams }: { searchParams: Promise<Record<string, string | string[] | undefined>> }) {
  const sp = await searchParams;
  const geo = await getGeo();
  return (
    <AuthShell title="إنشاء حساب جديد" subtitle="سيصلك رمز تأكيد لتفعيل الاشتراك" badge="تطبيق المسافر">
      <Flash sp={sp} />
      <form action={registerAction} className="space-y-3">
        <Field label="الاسم الكامل *">
          <input name="name" required className={inputCls} />
        </Field>
        <Field label="رقم الهاتف *">
          <input name="phone" required inputMode="tel" placeholder="09XXXXXXXX" className={inputCls} />
        </Field>
        <Field label="الرقم الوطني (إن وجد)">
          <input name="nationalId" className={inputCls} />
        </Field>
        <div className="grid grid-cols-2 gap-3">
          <Field label="الولاية">
            <StateSelect name="state" geo={geo} />
          </Field>
          <Field label="المدينة">
            <input name="city" list="cities" className={inputCls} />
            <CityList geo={geo} />
          </Field>
        </div>
        <Field label="البريد الإلكتروني (اختياري)">
          <input name="email" type="email" className={inputCls} />
        </Field>
        <div className="grid grid-cols-2 gap-3">
          <Field label="كلمة المرور *">
            <input name="password" type="password" required minLength={6} className={inputCls} />
          </Field>
          <Field label="تأكيد كلمة المرور *">
            <input name="confirm" type="password" required className={inputCls} />
          </Field>
        </div>
        <FileUpload name="avatar" label="صورة شخصية (اختياري)" />
        <button className={`${btnCls()} w-full`}>إنشاء الحساب</button>
      </form>
      <p className="mt-4 text-center text-sm text-slate-500">
        لديك حساب؟ <Link href="/passenger/login" className="font-semibold text-primary">تسجيل الدخول</Link>
      </p>
    </AuthShell>
  );
}
