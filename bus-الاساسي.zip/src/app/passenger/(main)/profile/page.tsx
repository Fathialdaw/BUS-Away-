import { desc, eq } from "drizzle-orm";
import { db } from "@/db";
import { bookings, payments } from "@/db/schema";
import { CityList, StateSelect } from "@/components/geo-select";
import { FileUpload } from "@/components/client";
import { Card, Field, Flash, Logo, StatusBadge, btnCls, inputCls } from "@/components/ui";
import { requirePassenger } from "@/lib/auth";
import { fmtDate, paymentStatus } from "@/lib/format";
import { getSettings } from "@/lib/settings";
import { getGeo } from "@/lib/trips";
import { changePasswordAction, deleteAccountAction, logoutAction, updateProfileAction } from "@/app/passenger/actions";

export const metadata = { title: "الملف الشخصي" };

export default async function ProfilePage({ searchParams }: { searchParams: Promise<Record<string, string | string[] | undefined>> }) {
  const sp = await searchParams;
  const p = await requirePassenger();
  const s = await getSettings();
  const geo = await getGeo();
  const receipts = await db
    .select({ pay: payments, b: bookings })
    .from(payments)
    .innerJoin(bookings, eq(bookings.id, payments.bookingId))
    .where(eq(bookings.passengerId, p.id))
    .orderBy(desc(payments.id))
    .limit(12);
  return (
    <div className="space-y-4">
      <Flash sp={sp} />
      <Card className="flex items-center gap-4">
        <Logo src={p.avatar} name={p.name} size={64} />
        <div>
          <div className="text-lg font-bold">{p.name}</div>
          <div className="text-sm text-slate-500">رقم الراكب: <b dir="ltr">{p.passengerNumber}</b></div>
          <div className="text-xs text-slate-400">عضو منذ {fmtDate(p.createdAt)}</div>
        </div>
      </Card>

      <Card>
        <h2 className="mb-3 text-sm font-bold">تعديل البيانات</h2>
        <form action={updateProfileAction} className="space-y-3">
          <Field label="الاسم الكامل"><input name="name" defaultValue={p.name} required className={inputCls} /></Field>
          <Field label="رقم الهاتف"><input name="phone" defaultValue={p.phone} required className={inputCls} /></Field>
          <Field label="الرقم الوطني"><input name="nationalId" defaultValue={p.nationalId ?? ""} className={inputCls} /></Field>
          <div className="grid grid-cols-2 gap-3">
            <Field label="الولاية"><StateSelect name="state" geo={geo} defaultValue={p.state} /></Field>
            <Field label="المدينة">
              <input name="city" list="cities" defaultValue={p.city ?? ""} className={inputCls} />
              <CityList geo={geo} />
            </Field>
          </div>
          <Field label="البريد الإلكتروني"><input name="email" type="email" defaultValue={p.email ?? ""} className={inputCls} /></Field>
          <FileUpload name="avatar" label="الصورة الشخصية" initial={p.avatar} />
          <button className={btnCls()}>حفظ التغييرات</button>
        </form>
      </Card>

      <Card>
        <h2 className="mb-3 text-sm font-bold">تغيير كلمة المرور</h2>
        <form action={changePasswordAction} className="space-y-3">
          <Field label="كلمة المرور الحالية"><input name="current" type="password" required className={inputCls} /></Field>
          <div className="grid grid-cols-2 gap-3">
            <Field label="الجديدة"><input name="next" type="password" minLength={6} required className={inputCls} /></Field>
            <Field label="تأكيد الجديدة"><input name="confirm" type="password" required className={inputCls} /></Field>
          </div>
          <button className={btnCls("outline")}>تغيير كلمة المرور</button>
        </form>
      </Card>

      <Card>
        <h2 className="mb-3 text-sm font-bold">صور إشعارات الدفع</h2>
        {receipts.length === 0 ? (
          <p className="text-sm text-slate-400">لا توجد إشعارات دفع مرفوعة</p>
        ) : (
          <div className="grid grid-cols-3 gap-3">
            {receipts.filter((r) => r.pay.receiptImage).map(({ pay, b }) => (
              <a key={pay.id} href={pay.receiptImage!} target="_blank" rel="noreferrer" className="block text-center">
                {/* eslint-disable-next-line @next/next/no-img-element */}
                <img src={pay.receiptImage!} alt="" className="h-24 w-full rounded-xl border object-cover" />
                <div className="mt-1 text-[10px] text-slate-500" dir="ltr">{b.bookingNumber}</div>
                <StatusBadge map={paymentStatus} value={pay.status} />
              </a>
            ))}
          </div>
        )}
      </Card>

      <Card className="space-y-2 text-sm">
        <h2 className="text-sm font-bold">الدعم والسياسات</h2>
        <p className="text-slate-500">📞 {s.contact_phone} • ✉️ {s.contact_email}</p>
        <details className="rounded-xl bg-slate-50 p-3"><summary className="cursor-pointer font-semibold">شروط الاستخدام</summary><p className="mt-2 whitespace-pre-line text-slate-600">{s.terms}</p></details>
        <details className="rounded-xl bg-slate-50 p-3"><summary className="cursor-pointer font-semibold">سياسة الإلغاء والاسترجاع</summary><p className="mt-2 text-slate-600">{s.cancellation_policy}</p></details>
      </Card>

      <form action={logoutAction}>
        <button className={`${btnCls("outline")} w-full`}>تسجيل الخروج</button>
      </form>

      <Card>
        <details>
          <summary className="cursor-pointer text-sm font-semibold text-red-600">حذف الحساب</summary>
          <form action={deleteAccountAction} className="mt-3 space-y-3">
            <p className="text-xs text-slate-500">سيتم مسح بياناتك الشخصية نهائياً. لا يمكن الحذف مع وجود حجوزات نشطة.</p>
            <Field label="أدخل كلمة المرور للتأكيد"><input name="password" type="password" required className={inputCls} /></Field>
            <button className={btnCls("danger")}>حذف حسابي نهائياً</button>
          </form>
        </details>
      </Card>
    </div>
  );
}
