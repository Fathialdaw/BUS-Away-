import Link from "next/link";
import type { ReactNode } from "react";
import { and, count, eq } from "drizzle-orm";
import { db } from "@/db";
import { notifications } from "@/db/schema";
import { NavLinks } from "@/components/client";
import { ThemeToggle } from "@/components/theme-toggle";
import { Logo } from "@/components/ui";
import { requirePassenger } from "@/lib/auth";
import { generateReminders } from "@/lib/booking";
import { getSettings } from "@/lib/settings";

export default async function MainLayout({ children }: { children: ReactNode }) {
  const p = await requirePassenger();
  const s = await getSettings();
  await generateReminders(p.id);
  const [{ c }] = await db
    .select({ c: count() })
    .from(notifications)
    .where(and(eq(notifications.passengerId, p.id), eq(notifications.isRead, false), eq(notifications.isDismissed, false)));
  return (
    <div className="min-h-screen pb-24">
      <header className="no-print sticky top-0 z-20 border-b border-slate-200 bg-white/95 backdrop-blur">
        <div className="mx-auto flex max-w-3xl items-center justify-between px-4 py-3">
          <Link href="/passenger" className="flex items-center gap-2">
            <Logo src={s.app_logo} name={s.app_name} size={34} />
            <span className="text-sm font-extrabold text-slate-900">{s.app_name}</span>
          </Link>
          <div className="flex items-center gap-2">
            <ThemeToggle returnTo="/passenger" />
            <Link href="/passenger/notifications" className="relative rounded-full bg-slate-100 p-2 text-lg" aria-label="التنبيهات">
              🔔
              {c > 0 && (
                <span className="absolute -top-1 -left-1 flex h-5 min-w-5 items-center justify-center rounded-full bg-red-600 px-1 text-[10px] font-bold text-white">
                  {c}
                </span>
              )}
            </Link>
          </div>
        </div>
      </header>
      <main className="mx-auto max-w-3xl p-4">{children}</main>
      <NavLinks
        variant="bottom"
        items={[
          { href: "/passenger", label: "الرئيسية", icon: "🏠", exact: true },
          { href: "/passenger/trips", label: "الرحلات", icon: "🚌" },
          { href: "/passenger/tickets", label: "التذاكر", icon: "🎫" },
          { href: "/passenger/notifications", label: "التنبيهات", icon: "🔔" },
          { href: "/passenger/profile", label: "الملف", icon: "👤" },
        ]}
      />
    </div>
  );
}
