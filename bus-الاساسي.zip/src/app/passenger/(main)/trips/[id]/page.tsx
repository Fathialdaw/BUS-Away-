import Link from "next/link";
import { notFound } from "next/navigation";
import { eq } from "drizzle-orm";
import { db } from "@/db";
import { companies, trips } from "@/db/schema";
import { Card, Flash, Logo, Row, StatusBadge, btnCls } from "@/components/ui";
import { requirePassenger } from "@/lib/auth";
import { releaseExpired } from "@/lib/booking";
import { depAt, fmtDate, fmtTime, money, tripStatus } from "@/lib/format";
import { getSettings } from "@/lib/settings";

export const metadata = { title: "تفاصيل الرحلة" };

export default async function TripDetails({
  params,
  searchParams,
}: {
  params: Promise<{ id: string }>;
  searchParams: Promise<Record<string, string | string[] | undefined>>;
}) {
  const { id } = await params;
  const sp = await searchParams;
  await requirePassenger();
  await releaseExpired();
  const s = await getSettings();
  const [r] = await db
    .select({ t: trips, c: companies })
    .from(trips)
    .innerJoin(companies, eq(companies.id, trips.companyId))
    .where(eq(trips.id, Number(id)));
  if (!r || r.c.status !== "active") notFound();
  const { t, c } = r;
  const bookable = t.status === "open" && t.availableSeats > 0 && depAt(t.departureDate, t.departureTime) > new Date();
  return (
    <div className="space-y-4">
      <Flash sp={sp} />
      <Link href="/passenger/trips" className="text-sm text-primary">← عودة للرحلات</Link>
      <Card>
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <Logo src={c.logo} name={c.name} size={44} />
            <div>
              <div className="font-bold">{c.name}</div>
              <div className="text-xs text-slate-500">{c.phone}</div>
            </div>
          </div>
          <StatusBadge map={tripStatus} value={t.status} />
        </div>
        <div className="my-4 flex items-center justify-center gap-3 text-2xl font-extrabold">
          <span>{t.fromCity}</span>
          <span className="text-primary">←</span>
          <span>{t.toCity}</span>
        </div>
        <Row k="خط السير" v={`${t.fromState} - ${t.fromCity} إلى ${t.toState} - ${t.toCity}`} />
        <Row k="تاريخ المغادرة" v={fmtDate(t.departureDate)} />
        <Row k="وقت المغادرة" v={fmtTime(t.departureTime)} />
        <Row k="وقت الوصول المتوقع" v={fmtTime(t.arrivalTime)} />
        <Row k="مكان التجمع" v={t.meetingPoint ?? "-"} />
        <Row k="نوع البص" v={t.busType} />
        <Row k="المقاعد المتاحة" v={`${t.availableSeats} من ${t.totalSeats}`} />
        <Row k="سعر التذكرة" v={<span className="text-lg font-bold text-primary">{money(t.price, s.currency)}</span>} />
        {t.notes && <Row k="ملاحظات" v={t.notes} />}
        {t.mapUrl && (
          <a href={t.mapUrl} target="_blank" rel="noreferrer" className="mt-3 inline-block text-sm font-semibold text-primary">
            📍 عرض نقطة المغادرة على الخريطة
          </a>
        )}
      </Card>
      <Card>
        <h3 className="mb-2 text-sm font-bold">معلومات الشركة</h3>
        <Row k="العنوان" v={c.address ?? "-"} />
        <Row k="الهاتف" v={c.phone ?? "-"} />
        <Row k="البريد" v={c.email ?? "-"} />
        <Row k="رقم الترخيص" v={c.licenseNumber ?? "-"} />
        {c.routes && <Row k="خطوط العمل" v={c.routes} />}
      </Card>
      {bookable ? (
        <Link href={`/passenger/trips/${t.id}/seats`} className={`${btnCls()} w-full py-3 text-base`}>
          💺 اختيار المقعد ومتابعة الحجز
        </Link>
      ) : (
        <div className="rounded-xl bg-slate-200 p-3 text-center text-sm text-slate-600">هذه الرحلة غير متاحة للحجز حالياً</div>
      )}
    </div>
  );
}
