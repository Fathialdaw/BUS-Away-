import Link from "next/link";
import { and, desc, eq, inArray } from "drizzle-orm";
import { db } from "@/db";
import { bookings, companies, notifications, trips } from "@/db/schema";
import { GeoSelect } from "@/components/geo-select";
import { NotificationCard } from "@/components/notif";
import { TripCard } from "@/components/trip-card";
import { Card, Empty, Flash, Logo, StatusBadge, btnCls, inputCls } from "@/components/ui";
import { requirePassenger } from "@/lib/auth";
import { releaseExpired } from "@/lib/booking";
import { bookingStatus, depAt, fmtDate, fmtTime, todayStr } from "@/lib/format";
import { getSettings } from "@/lib/settings";
import { getGeo, searchTrips } from "@/lib/trips";

export const metadata = { title: "الرئيسية" };

export default async function PassengerHome({ searchParams }: { searchParams: Promise<Record<string, string | string[] | undefined>> }) {
  const sp = await searchParams;
  const p = await requirePassenger();
  const s = await getSettings();
  await releaseExpired();
  const geo = await getGeo();
  const alerts = await db
    .select()
    .from(notifications)
    .where(and(eq(notifications.passengerId, p.id), eq(notifications.isRead, false), eq(notifications.isDismissed, false)))
    .orderBy(desc(notifications.id))
    .limit(4);
  const mine = await db
    .select({ b: bookings, t: trips, c: companies })
    .from(bookings)
    .innerJoin(trips, eq(trips.id, bookings.tripId))
    .innerJoin(companies, eq(companies.id, bookings.companyId))
    .where(eq(bookings.passengerId, p.id))
    .orderBy(desc(bookings.id))
    .limit(30);
  const now = new Date();
  const upcoming = mine.filter((r) => r.b.status === "confirmed" && depAt(r.t.departureDate, r.t.departureTime) > now);
  const latest = mine.slice(0, 3);
  const available = await searchTrips({ limit: 4 });
  const cos = await db.select().from(companies).where(eq(companies.status, "active"));
  void todayStr;
  void inArray;
  return (
    <div className="space-y-5">
      <Flash sp={sp} />
      <div className="rounded-3xl bg-gradient-to-l from-primary to-primary/70 p-5 text-white shadow-lg">
        <div className="text-sm opacity-80">مرحباً بك 👋</div>
        <div className="mt-1 text-xl font-extrabold">{p.name}</div>
        <div className="mt-1 text-xs opacity-90">رقم الراكب: <b dir="ltr">{p.passengerNumber}</b></div>
      </div>

      <Card>
        <h2 className="mb-3 text-sm font-bold">ابحث عن رحلة</h2>
        <form action="/passenger/trips" className="grid gap-3 sm:grid-cols-4">
          <GeoSelect name="from" geo={geo} placeholder="من (ولاية / مدينة)" />
          <GeoSelect name="to" geo={geo} placeholder="إلى (ولاية / مدينة)" />
          <input type="date" name="date" min={todayStr()} className={inputCls} />
          <button className={btnCls()}>🔍 بحث</button>
        </form>
      </Card>

      {alerts.length > 0 && (
        <section className="space-y-3">
          <h2 className="text-sm font-bold text-slate-800">تنبيهات مهمة</h2>
          {alerts.map((n) => (
            <NotificationCard key={n.id} n={n} returnTo="/passenger" />
          ))}
        </section>
      )}

      <section>
        <h2 className="mb-3 text-sm font-bold text-slate-800">رحلاتي القادمة</h2>
        {upcoming.length === 0 ? (
          <Empty icon="🧳" text="لا توجد رحلات قادمة مؤكدة" />
        ) : (
          <div className="space-y-3">
            {upcoming.map(({ b, t, c }) => (
              <Link key={b.id} href={`/passenger/tickets/${b.id}`} className="flex items-center justify-between rounded-2xl bg-white p-4 ring-1 ring-slate-200">
                <div>
                  <div className="font-bold">{t.fromCity} ← {t.toCity}</div>
                  <div className="mt-1 text-xs text-slate-500">{c.name} • {fmtDate(t.departureDate)} • {fmtTime(t.departureTime)}</div>
                </div>
                <div className="text-center">
                  <div className="text-[10px] text-slate-400">المقعد</div>
                  <div className="text-xl font-extrabold text-primary">{b.seatNumber}</div>
                </div>
              </Link>
            ))}
          </div>
        )}
      </section>

      <section>
        <div className="mb-3 flex items-center justify-between">
          <h2 className="text-sm font-bold text-slate-800">الرحلات المتاحة</h2>
          <Link href="/passenger/trips" className="text-xs font-semibold text-primary">عرض الكل</Link>
        </div>
        <div className="grid gap-3 sm:grid-cols-2">
          {available.map(({ trip, company }) => (
            <TripCard key={trip.id} trip={trip} company={company} currency={s.currency} href={`/passenger/trips/${trip.id}`} />
          ))}
        </div>
        {available.length === 0 && <Empty text="لا توجد رحلات متاحة حالياً" icon="🚌" />}
      </section>

      <section>
        <h2 className="mb-3 text-sm font-bold text-slate-800">الشركات المتاحة</h2>
        <div className="flex gap-3 overflow-x-auto pb-1">
          {cos.map((c) => (
            <Link key={c.id} href={`/passenger/trips?company=${c.id}`} className="flex min-w-28 flex-col items-center gap-2 rounded-2xl bg-white p-3 text-center ring-1 ring-slate-200">
              <Logo src={c.logo} name={c.name} size={44} />
              <span className="text-xs font-semibold">{c.name}</span>
            </Link>
          ))}
        </div>
      </section>

      <section>
        <h2 className="mb-3 text-sm font-bold text-slate-800">آخر الحجوزات</h2>
        {latest.length === 0 ? (
          <Empty text="لم تقم بأي حجز بعد" icon="🎫" />
        ) : (
          <div className="space-y-2">
            {latest.map(({ b, t }) => (
              <Link key={b.id} href={`/passenger/booking/${b.id}`} className="flex items-center justify-between rounded-2xl bg-white p-3 text-sm ring-1 ring-slate-200">
                <div>
                  <div className="font-semibold">{t.fromCity} ← {t.toCity}</div>
                  <div className="text-xs text-slate-400">{b.bookingNumber} • {fmtDate(t.departureDate)}</div>
                </div>
                <StatusBadge map={bookingStatus} value={b.status} />
              </Link>
            ))}
          </div>
        )}
      </section>
    </div>
  );
}
