"use server";

import { and, eq, inArray, or, sql } from "drizzle-orm";
import { db } from "@/db";
import {
  adminBookingRequests,
  bookings,
  cities,
  companies,
  companyAccounts,
  messages,
  passengers,
  paymentTypes,
  payments,
  settings,
  states,
  trips,
  users,
} from "@/db/schema";
import { clearSession, hashPassword, requireAdmin, setSession, verifyPassword } from "@/lib/auth";
import { ACTIVE, audit, type Actor } from "@/lib/booking";
import { clearTripsAndBookingsAll, reseedAll } from "@/lib/reseed";
import { str } from "@/lib/format";
import { go } from "@/lib/nav";
import { normPhone } from "@/lib/otp";
import { DEFAULTS } from "@/lib/settings";

const actor = (u: { id: number; name: string }): Actor => ({ userId: u.id, name: u.name, type: "admin" });

export async function adminLoginAction(fd: FormData): Promise<void> {
  const id = str(fd.get("identifier"));
  const pw = str(fd.get("password"));
  const [u] = await db
    .select()
    .from(users)
    .where(or(eq(users.email, id.toLowerCase()), eq(users.phone, normPhone(id))));
  if (!u || u.role !== "system_admin" || !verifyPassword(pw, u.password)) go("/admin/login", { error: "بيانات الدخول غير صحيحة" });
  if (u.status !== "active") go("/admin/login", { error: "هذا الحساب معطل" });
  await setSession("admin", u.id);
  await db.update(users).set({ lastLoginAt: new Date() }).where(eq(users.id, u.id));
  await audit(actor(u), "login", "user", u.id);
  go("/admin");
}

export async function adminLogoutAction(): Promise<void> {
  await clearSession("admin");
  go("/admin/login");
}

/* ---------- الشركات ---------- */

export async function saveCompanyAction(fd: FormData): Promise<void> {
  const admin = await requireAdmin();
  const id = Number(str(fd.get("id"))) || 0;
  const back = id ? `/admin/companies/${id}` : "/admin/companies/new";
  const v = {
    name: str(fd.get("name")),
    logo: str(fd.get("logo")) || null,
    phone: str(fd.get("phone")) || null,
    email: str(fd.get("email")) || null,
    address: str(fd.get("address")) || null,
    licenseNumber: str(fd.get("licenseNumber")) || null,
    routes: str(fd.get("routes")) || null,
    status: ["active", "suspended", "pending"].includes(str(fd.get("status"))) ? str(fd.get("status")) : "pending",
  };
  if (!v.name) go(back, { error: "اسم الشركة مطلوب" });
  if (id) {
    const [old] = await db.select().from(companies).where(eq(companies.id, id));
    await db.update(companies).set(v).where(eq(companies.id, id));
    await audit(actor(admin), "update_company", "company", id, old, v);
    go(`/admin/companies/${id}`, { ok: "تم حفظ بيانات الشركة" });
  }
  const mName = str(fd.get("managerName"));
  const mPhone = normPhone(str(fd.get("managerPhone")));
  const mEmail = str(fd.get("managerEmail")).toLowerCase() || null;
  const mPw = str(fd.get("managerPassword"));
  if (mName || mPhone || mPw) {
    if (!mName || !mPhone || mPw.length < 6) go(back, { error: "أكمل بيانات مدير المكتب (كلمة المرور 6 أحرف على الأقل)" });
    const dup = await db.select({ id: users.id }).from(users).where(mEmail ? or(eq(users.phone, mPhone), eq(users.email, mEmail)) : eq(users.phone, mPhone));
    if (dup.length) go(back, { error: "هاتف أو بريد مدير المكتب مستخدم مسبقاً" });
  }
  const [c] = await db.insert(companies).values(v).returning();
  if (mName && mPhone && mPw)
    await db.insert(users).values({ name: mName, phone: mPhone, email: mEmail, password: hashPassword(mPw), role: "company_manager", companyId: c.id });
  await audit(actor(admin), "create_company", "company", c.id, null, v);
  go(`/admin/companies/${c.id}`, { ok: "تمت إضافة الشركة" });
}

export async function deleteCompanyAction(fd: FormData): Promise<void> {
  const admin = await requireAdmin();
  const id = Number(str(fd.get("id")));
  const t = await db.select({ id: trips.id }).from(trips).where(eq(trips.companyId, id)).limit(1);
  if (t.length) go(`/admin/companies/${id}`, { error: "لا يمكن حذف شركة لها رحلات، قم بإيقافها بدلاً من ذلك" });
  try {
    await db.execute(sql`delete from admin_booking_requests where company_id = ${id}`);
    await db.execute(sql`delete from expenses where company_id = ${id}`);
    await db.delete(companyAccounts).where(eq(companyAccounts.companyId, id));
    await db.delete(users).where(eq(users.companyId, id));
    await db.delete(companies).where(eq(companies.id, id));
  } catch {
    go(`/admin/companies/${id}`, { error: "تعذر الحذف لوجود بيانات مرتبطة، قم بإيقاف الشركة بدلاً من ذلك" });
  }
  await audit(actor(admin), "delete_company", "company", id);
  go("/admin/companies", { ok: "تم حذف الشركة" });
}

/* ---------- المستخدمون ---------- */

export async function saveUserAction(fd: FormData): Promise<void> {
  const admin = await requireAdmin();
  const id = Number(str(fd.get("id"))) || 0;
  const back = "/admin/users";
  const role = str(fd.get("role"));
  if (!["system_admin", "company_manager", "employee"].includes(role)) go(back, { error: "الصلاحية غير صحيحة" });
  const companyId = Number(str(fd.get("companyId"))) || null;
  if (role !== "system_admin" && !companyId) go(back, { error: "اربط المستخدم بشركة" });
  const name = str(fd.get("name"));
  const phone = normPhone(str(fd.get("phone")));
  const email = str(fd.get("email")).toLowerCase() || null;
  const pw = str(fd.get("password"));
  if (!name || !phone) go(back, { error: "الاسم والهاتف مطلوبان" });
  const status = str(fd.get("status")) === "disabled" ? "disabled" : "active";
  const dups = await db.select({ id: users.id }).from(users).where(email ? or(eq(users.phone, phone), eq(users.email, email)) : eq(users.phone, phone));
  if (dups.some((d) => d.id !== id)) go(back, { error: "الهاتف أو البريد مستخدم لحساب آخر" });
  const permissions = role === "employee" ? fd.getAll("perms").map(String) : [];
  const base = { name, phone, email, role, companyId: role === "system_admin" ? null : companyId, status, permissions };
  if (id) {
    if (id === admin.id && (status === "disabled" || role !== "system_admin")) go(back, { error: "لا يمكنك تعطيل حسابك أو تغيير صلاحيتك" });
    const set: Partial<typeof users.$inferInsert> = { ...base };
    if (pw) {
      if (pw.length < 6) go(back, { error: "كلمة المرور قصيرة" });
      set.password = hashPassword(pw);
    }
    await db.update(users).set(set).where(eq(users.id, id));
    await audit(actor(admin), "update_user", "user", id, null, base);
    go(back, { ok: "تم تحديث المستخدم" });
  }
  if (pw.length < 6) go(back, { error: "كلمة المرور يجب ألا تقل عن 6 أحرف" });
  const [u] = await db.insert(users).values({ ...base, password: hashPassword(pw) }).returning();
  await audit(actor(admin), "create_user", "user", u.id, null, base);
  go(back, { ok: "تم إنشاء المستخدم" });
}

export async function setPassengerStatusAction(fd: FormData): Promise<void> {
  const admin = await requireAdmin();
  const id = Number(str(fd.get("id")));
  const status = str(fd.get("status"));
  if (!["active", "suspended", "inactive"].includes(status)) go("/admin/passengers", { error: "حالة غير صحيحة" });
  await db.update(passengers).set({ status }).where(eq(passengers.id, id));
  await audit(actor(admin), "set_passenger_status", "passenger", id, null, { status });
  go("/admin/passengers", { ok: "تم تحديث حالة الراكب" });
}

/* ---------- الإعدادات ---------- */

export async function saveSettingsAction(fd: FormData): Promise<void> {
  const admin = await requireAdmin();
  const keys = Object.keys(DEFAULTS);
  const changed: Record<string, string> = {};
  for (const k of keys) {
    if (k === "employee_chat_allowed") {
      changed[k] = fd.get(k) ? "true" : "false";
      continue;
    }
    if (!fd.has(k)) continue;
    changed[k] = str(fd.get(k));
  }
  if (changed.hold_minutes && !(Number(changed.hold_minutes) > 0)) go("/admin/settings", { error: "مدة الاحتفاظ بالحجز غير صحيحة" });
  if (changed.primary_color && !/^#[0-9a-fA-F]{6}$/.test(changed.primary_color)) go("/admin/settings", { error: "اللون غير صحيح" });
  for (const [key, value] of Object.entries(changed)) {
    await db.insert(settings).values({ key, value }).onConflictDoUpdate({ target: settings.key, set: { value } });
  }
  await audit(actor(admin), "update_settings", "settings", null, null, changed);
  go("/admin/settings", { ok: "تم حفظ الإعدادات" });
}

export async function saveBrandingAction(fd: FormData): Promise<void> {
  const admin = await requireAdmin();
  const values: Record<string, string> = {};
  for (const k of ["app_logo", "app_icon"]) {
    if (!fd.has(k)) continue;
    const v = str(fd.get(k));
    if (v && !v.startsWith("/api/files/")) go("/admin/settings", { error: "مصدر الصورة غير صالح" });
    values[k] = v;
  }
  for (const [key, value] of Object.entries(values)) {
    await db.insert(settings).values({ key, value }).onConflictDoUpdate({ target: settings.key, set: { value } });
  }
  await audit(actor(admin), "update_branding", "settings", null, null, values);
  go("/admin/settings", { ok: "تم تحديث الشعار وأيقونة التطبيق" });
}

/* ---------- الولايات والمدن وطرق الدفع ---------- */

export async function addStateAction(fd: FormData): Promise<void> {
  const admin = await requireAdmin();
  const name = str(fd.get("name"));
  if (!name) go("/admin/geo", { error: "اكتب اسم الولاية" });
  try {
    await db.insert(states).values({ name });
  } catch {
    go("/admin/geo", { error: "الولاية موجودة مسبقاً" });
  }
  await audit(actor(admin), "create_state", "state", null, null, { name });
  go("/admin/geo", { ok: "تمت إضافة الولاية" });
}

export async function deleteStateAction(fd: FormData): Promise<void> {
  const admin = await requireAdmin();
  const id = Number(str(fd.get("id")));
  await db.delete(states).where(eq(states.id, id));
  await audit(actor(admin), "delete_state", "state", id);
  go("/admin/geo", { ok: "تم حذف الولاية ومدنها" });
}

export async function addCityAction(fd: FormData): Promise<void> {
  const admin = await requireAdmin();
  const stateId = Number(str(fd.get("stateId")));
  const name = str(fd.get("name"));
  if (!stateId || !name) go("/admin/geo", { error: "أكمل البيانات" });
  await db.insert(cities).values({ stateId, name });
  await audit(actor(admin), "create_city", "city", null, null, { name, stateId });
  go("/admin/geo", { ok: "تمت إضافة المدينة" });
}

export async function deleteCityAction(fd: FormData): Promise<void> {
  const admin = await requireAdmin();
  const id = Number(str(fd.get("id")));
  await db.delete(cities).where(eq(cities.id, id));
  await audit(actor(admin), "delete_city", "city", id);
  go("/admin/geo", { ok: "تم حذف المدينة" });
}

export async function addPaymentTypeAction(fd: FormData): Promise<void> {
  const admin = await requireAdmin();
  const name = str(fd.get("name"));
  if (!name) go("/admin/payment-types", { error: "اكتب اسم طريقة الدفع" });
  try {
    await db.insert(paymentTypes).values({ name });
  } catch {
    go("/admin/payment-types", { error: "الطريقة موجودة مسبقاً" });
  }
  await audit(actor(admin), "create_payment_type", "payment_type", null, null, { name });
  go("/admin/payment-types", { ok: "تمت إضافة طريقة الدفع" });
}

export async function togglePaymentTypeAction(fd: FormData): Promise<void> {
  const admin = await requireAdmin();
  const id = Number(str(fd.get("id")));
  await db.update(paymentTypes).set({ active: sql`not ${paymentTypes.active}` }).where(eq(paymentTypes.id, id));
  await audit(actor(admin), "toggle_payment_type", "payment_type", id);
  go("/admin/payment-types", { ok: "تم تحديث الحالة" });
}

export async function deletePaymentTypeAction(fd: FormData): Promise<void> {
  const admin = await requireAdmin();
  const id = Number(str(fd.get("id")));
  const [t] = await db.select().from(paymentTypes).where(eq(paymentTypes.id, id));
  if (!t) go("/admin/payment-types");
  const used = await db.select({ id: companyAccounts.id }).from(companyAccounts).where(eq(companyAccounts.paymentType, t.name)).limit(1);
  const used2 = await db.select({ id: payments.id }).from(payments).where(eq(payments.paymentMethod, t.name)).limit(1);
  if (used.length || used2.length) go("/admin/payment-types", { error: "الطريقة مستخدمة، عطّلها بدلاً من حذفها" });
  await db.delete(paymentTypes).where(eq(paymentTypes.id, id));
  await audit(actor(admin), "delete_payment_type", "payment_type", id);
  go("/admin/payment-types", { ok: "تم الحذف" });
}

/* ---------- طلبات الحجز باسم شركة ---------- */

export async function createBookingRequestAction(fd: FormData): Promise<void> {
  const admin = await requireAdmin();
  const P = "/admin/requests";
  const tripId = Number(str(fd.get("tripId")));
  const passengerId = Number(str(fd.get("passengerId")));
  const seat = Number(str(fd.get("seat")));
  const [t] = await db.select().from(trips).where(eq(trips.id, tripId));
  if (!t) go(P, { error: "اختر رحلة" });
  const [p] = await db.select().from(passengers).where(eq(passengers.id, passengerId));
  if (!p) go(P, { error: "اختر راكباً" });
  if (!Number.isInteger(seat) || seat < 1 || seat > t.totalSeats) go(P, { error: "رقم المقعد غير صحيح" });
  const taken = await db
    .select({ id: bookings.id })
    .from(bookings)
    .where(and(eq(bookings.tripId, tripId), eq(bookings.seatNumber, seat), inArray(bookings.status, ACTIVE)));
  if (taken.length) go(P, { error: "المقعد محجوز بالفعل" });
  const [r] = await db
    .insert(adminBookingRequests)
    .values({ adminId: admin.id, companyId: t.companyId, tripId, passengerId, seatNumber: seat, note: str(fd.get("note")) || null })
    .returning();
  await audit({ ...actor(admin), companyId: t.companyId }, "request_booking_for_company", "admin_booking_request", r.id, null, { tripId, passengerId, seat });
  go(P, { ok: "تم إرسال الطلب إلى مدير المكتب، وسيُنفذ الحجز بعد موافقته" });
}

export async function clearTripsBookingsAction(): Promise<void> {
  const admin = await requireAdmin();
  await clearTripsAndBookingsAll();
  await audit(actor(admin), "clear_trips_bookings_all", "system", null);
  go("/admin", { ok: "تم حذف جميع الرحلات والحجوزات والمدفوعات والتذاكر في النظام" });
}

export async function resetDemoDataAction(): Promise<void> {
  const admin = await requireAdmin();
  await reseedAll();
  await audit({ userId: null, name: admin.name, type: "system" }, "reset_demo_data_all", "system", null);
  go("/admin/login", { ok: "تمت تهيئة النظام: أُعيدت الشركات والحجوزات إلى حالة العرض الأولى. سجّل الدخول مجدداً." });
}

/* ---------- مراقبة الدردشة ---------- */

export async function clearReportAction(fd: FormData): Promise<void> {
  const admin = await requireAdmin();
  const id = Number(str(fd.get("id")));
  await db.update(messages).set({ reported: false }).where(eq(messages.id, id));
  await audit(actor(admin), "clear_report", "message", id);
  go("/admin/chat", { ok: "تم إغلاق البلاغ" });
}
