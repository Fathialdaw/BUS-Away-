import type { Metadata, Viewport } from "next";
import type { CSSProperties, ReactNode } from "react";
import { InstallPrompt } from "@/components/client";
import { getSettings } from "@/lib/settings";

export async function generateMetadata(): Promise<Metadata> {
  const s = await getSettings();
  return {
    title: { default: `مدير النظام | ${s.app_name}`, template: `%s | مدير النظام` },
    manifest: "/admin/manifest.webmanifest",
    applicationName: `${s.app_name} - مدير النظام`,
    appleWebApp: { capable: true, title: "مدير النظام", statusBarStyle: "default" },
    icons: { icon: "/icons/admin-512.png", apple: "/icons/admin-512.png" },
  };
}

export const viewport: Viewport = { themeColor: "#6d28d9", width: "device-width", initialScale: 1 };

export default function AdminLayout({ children }: { children: ReactNode }) {
  return (
    <div style={{ "--primary": "#6d28d9" } as CSSProperties} className="min-h-screen">
      <InstallPrompt app="admin" label="تطبيق مدير النظام" />
      {children}
    </div>
  );
}
