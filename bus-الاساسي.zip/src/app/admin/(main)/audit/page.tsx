import { desc, eq } from "drizzle-orm";
import { db } from "@/db";
import { auditLogs } from "@/db/schema";
import { Empty, PageTitle, btnCls, inputCls, td, th } from "@/components/ui";
import { fmtDateTime, one } from "@/lib/format";

export const metadata = { title: "سجل العمليات" };

export default async function AdminAudit({ searchParams }: { searchParams: Promise<Record<string, string | string[] | undefined>> }) {
  const sp = await searchParams;
  const action = one(sp.action);
  const q = db.select().from(auditLogs);
  const rows = await (action ? q.where(eq(auditLogs.action, action)) : q).orderBy(desc(auditLogs.id)).limit(200);
  return (
    <div className="space-y-4">
      <PageTitle title="سجل العمليات والمراقبة" subtitle="آخر 200 عملية" />
      <form className="flex gap-2">
        <input name="action" defaultValue={action} placeholder="تصفية بنوع العملية، مثال: login" dir="ltr" className={`${inputCls} max-w-xs`} />
        <button className={btnCls()}>تصفية</button>
      </form>
      {rows.length === 0 ? (
        <Empty text="لا توجد عمليات" icon="🛡️" />
      ) : (
        <div className="overflow-x-auto rounded-2xl bg-white ring-1 ring-slate-200">
          <table className="w-full min-w-[800px]">
            <thead><tr>{["الوقت", "المنفذ", "النوع", "العملية", "الكيان", "التفاصيل"].map((h) => <th key={h} className={th}>{h}</th>)}</tr></thead>
            <tbody className="divide-y divide-slate-100">
              {rows.map((l) => (
                <tr key={l.id} className="align-top">
                  <td className={td}>{fmtDateTime(l.createdAt)}</td>
                  <td className={td}>{l.actorName}</td>
                  <td className={td}>{l.actorType}</td>
                  <td className={`${td} font-mono text-xs`}>{l.action}</td>
                  <td className={td}>{l.entityType} {l.entityId ? `#${l.entityId}` : ""}</td>
                  <td className="max-w-xs truncate px-3 py-2.5 font-mono text-[10px] text-slate-400" dir="ltr">{l.newData ? JSON.stringify(l.newData).slice(0, 120) : ""}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}
