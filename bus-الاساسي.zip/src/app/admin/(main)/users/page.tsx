import { asc, eq } from "drizzle-orm";
import { db } from "@/db";
import { companies, users } from "@/db/schema";
import { Card, Field, Flash, PageTitle, StatusBadge, btnCls, inputCls, td, th } from "@/components/ui";
import { PERMS, fmtDateTime, roleLabel, userStatus } from "@/lib/format";
import { saveUserAction } from "@/app/admin/actions";

export const metadata = { title: "المستخدمون" };

export default async function AdminUsers({ searchParams }: { searchParams: Promise<Record<string, string | string[] | undefined>> }) {
  const sp = await searchParams;
  const rows = await db.select({ u: users, c: companies }).from(users).leftJoin(companies, eq(companies.id, users.companyId)).orderBy(asc(users.id));
  const cos = await db.select().from(companies).orderBy(asc(companies.name));
  const form = (u?: typeof users.$inferSelect) => (
    <form action={saveUserAction} className="space-y-3">
      {u && <input type="hidden" name="id" value={u.id} />}
      <div className="grid gap-3 sm:grid-cols-3">
        <Field label="الاسم"><input name="name" required defaultValue={u?.name} className={inputCls} /></Field>
        <Field label="الهاتف"><input name="phone" required defaultValue={u?.phone} className={inputCls} /></Field>
        <Field label="البريد الإلكتروني"><input name="email" type="email" defaultValue={u?.email ?? ""} className={inputCls} /></Field>
        <Field label="الصلاحية">
          <select name="role" defaultValue={u?.role ?? "employee"} className={inputCls}>
            {Object.entries(roleLabel).map(([k, v]) => <option key={k} value={k}>{v}</option>)}
          </select>
        </Field>
        <Field label="الشركة (لغير مدير النظام)">
          <select name="companyId" defaultValue={u?.companyId ?? ""} className={inputCls}>
            <option value="">-</option>
            {cos.map((c) => <option key={c.id} value={c.id}>{c.name}</option>)}
          </select>
        </Field>
        <Field label="الحالة">
          <select name="status" defaultValue={u?.status ?? "active"} className={inputCls}>
            <option value="active">نشط</option>
            <option value="disabled">معطل</option>
          </select>
        </Field>
        <Field label={u ? "كلمة مرور جديدة (اختياري)" : "كلمة المرور"}>
          <input name="password" type="password" required={!u} className={inputCls} />
        </Field>
      </div>
      <div className="flex flex-wrap gap-3">
        <span className="text-xs text-slate-500">صلاحيات الموظف:</span>
        {PERMS.map((p) => (
          <label key={p.key} className="flex items-center gap-1.5 text-xs">
            <input type="checkbox" name="perms" value={p.key} defaultChecked={u ? (u.permissions ?? []).includes(p.key) : p.key !== "trips"} /> {p.label}
          </label>
        ))}
      </div>
      <button className={btnCls(u ? "outline" : "primary", !!u)}>{u ? "حفظ" : "إنشاء المستخدم"}</button>
    </form>
  );
  return (
    <div className="space-y-4">
      <PageTitle title="إدارة المستخدمين" subtitle={`${rows.length} مستخدم`} />
      <Flash sp={sp} />
      <Card>
        <h2 className="mb-3 text-sm font-bold">إضافة مستخدم</h2>
        {form()}
      </Card>
      <div className="overflow-x-auto rounded-2xl bg-white ring-1 ring-slate-200">
        <table className="w-full min-w-[800px]">
          <thead><tr>{["الاسم", "الهاتف", "البريد", "الصلاحية", "الشركة", "الحالة", "آخر دخول"].map((h) => <th key={h} className={th}>{h}</th>)}</tr></thead>
          <tbody className="divide-y divide-slate-100">
            {rows.map(({ u, c }) => (
              <tr key={u.id} className="align-top">
                <td className={`${td} font-semibold`}>{u.name}</td>
                <td className={td} dir="ltr">{u.phone}</td>
                <td className={td} dir="ltr">{u.email ?? "-"}</td>
                <td className={td}>{roleLabel[u.role]}</td>
                <td className={td}>{c?.name ?? "-"}</td>
                <td className={td}><StatusBadge map={userStatus} value={u.status} /></td>
                <td className={td}>{fmtDateTime(u.lastLoginAt)}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      <h2 className="text-sm font-bold">تعديل المستخدمين</h2>
      <div className="grid gap-3">
        {rows.map(({ u }) => (
          <Card key={u.id}>
            <details>
              <summary className="cursor-pointer text-sm font-semibold">{u.name} — {roleLabel[u.role]}</summary>
              <div className="mt-3">{form(u)}</div>
            </details>
          </Card>
        ))}
      </div>
    </div>
  );
}
