import { desc } from "drizzle-orm";
import { db } from "@/db";
import { auditLogs } from "@/db/schema";
import { ConfirmButton } from "@/components/client";
import { Card, Flash, PageTitle, StatCard, btnCls, td, th } from "@/components/ui";
import { requireAdmin } from "@/lib/auth";
import { releaseExpired } from "@/lib/booking";
import { fmtDateTime, money } from "@/lib/format";
import { getStats } from "@/lib/reports";
import { getSettings } from "@/lib/settings";
import { clearTripsBookingsAction, resetDemoDataAction } from "@/app/admin/actions";

export const metadata = { title: "لوحة التحكم" };

export default async function AdminDashboard({ searchParams }: { searchParams: Promise<Record<string, string | string[] | undefined>> }) {
  const sp = await searchParams;
  const admin = await requireAdmin();
  await releaseExpired();
  const s = await getSettings();
  const st = await getStats();
  const logs = await db.select().from(auditLogs).orderBy(desc(auditLogs.id)).limit(8);
  return (
    <div>
      <Flash sp={sp} />
      <PageTitle title={`مرحباً ${admin.name}`} subtitle="نظرة عامة على النظام بالكامل" />
      <div className="grid grid-cols-2 gap-3 md:grid-cols-3 xl:grid-cols-4">
        <StatCard icon="🏢" label="عدد الشركات" value={st.companies} />
        <StatCard icon="🚌" label="عدد الرحلات" value={st.trips} />
        <StatCard icon="📅" label="الرحلات القادمة" value={st.upcoming} />
        <StatCard icon="🎫" label="عدد الحجوزات" value={st.bookings} />
        <StatCard icon="✅" label="التذاكر المؤكدة" value={st.tickets} />
        <StatCard icon="💺" label="المقاعد المتاحة" value={st.avail} hint="الرحلات القادمة" />
        <StatCard icon="🧍" label="المقاعد المحجوزة" value={st.booked} hint="الرحلات القادمة" />
        <StatCard icon="💰" label="المبالغ المحصلة" value={money(st.collected, s.currency)} />
        <StatCard icon="⏳" label="تحويلات قيد المراجعة" value={st.pending} />
        <StatCard icon="👤" label="الركاب المسجلون" value={st.passengers} />
        <StatCard icon="👥" label="مستخدمو النظام" value={st.users} />
      </div>
      <Card className="mt-6">
        <h2 className="mb-3 text-sm font-bold">آخر العمليات</h2>
        <div className="overflow-x-auto">
          <table className="w-full min-w-[560px]">
            <thead><tr>{["الوقت", "المنفذ", "العملية", "الكيان"].map((h) => <th key={h} className={th}>{h}</th>)}</tr></thead>
            <tbody className="divide-y divide-slate-100">
              {logs.map((l) => (
                <tr key={l.id}>
                  <td className={td}>{fmtDateTime(l.createdAt)}</td>
                  <td className={td}>{l.actorName}</td>
                  <td className={`${td} font-mono text-xs`}>{l.action}</td>
                  <td className={td}>{l.entityType} {l.entityId ? `#${l.entityId}` : ""}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </Card>
      <Card className="mt-6">
        <h2 className="text-sm font-bold text-red-700">⚠️ تهيئة النظام (لأغراض العرض)</h2>
        <p className="mt-2 text-xs leading-6 text-slate-500">
          يعيد النظام إلى حالة العرض الأولى: تُحذف جميع الحجوزات والمدفوعات والتذاكر والرحلات الحالية، وتُعاد الشركات التجريبية الثلاث
          مع بياناتها. تنتهي جلسات المديرين والموظفين الحاليين وستُطلب منك إعادة تسجيل الدخول.
        </p>
        <p className="mt-3 text-xs leading-6 text-slate-500">
          <b className="text-red-600">حذف الرحلات والحجوزات:</b> يحذف جميع رحلات النظام وحجوزاتها ومدفوعاتها وتذاكرها ومصروفاتها دون
          حذف الشركات أو المستخدمين أو الركاب.
        </p>
        <div className="mt-3 flex flex-wrap gap-2">
          <form action={clearTripsBookingsAction}>
            <ConfirmButton
              message="هل أنت متأكد؟ سيتم حذف جميع الرحلات والحجوزات في النظام بالكامل. لا يمكن التراجع."
              className={btnCls("danger")}
            >
              حذف جميع الرحلات والحجوزات
            </ConfirmButton>
          </form>
          <form action={resetDemoDataAction}>
            <ConfirmButton
              message="هل أنت متأكد؟ ستُحذف كل البيانات الحالية (الحجوزات والشركات) وتُعاد بيانات العرض التجريبية من البداية. لا يمكن التراجع."
              className={btnCls("outline")}
            >
              تهيئة بيانات العرض (الشركات والحجوزات)
            </ConfirmButton>
          </form>
        </div>
      </Card>
    </div>
  );
}
