import { ReportView } from "@/components/charts";
import { PageTitle } from "@/components/ui";
import { getReport } from "@/lib/reports";
import { getSettings } from "@/lib/settings";

export const metadata = { title: "الرسوم البيانية" };

export default async function AdminReports() {
  const s = await getSettings();
  const r = await getReport();
  return (
    <div>
      <PageTitle title="التقارير العامة والرسوم البيانية" subtitle="جميع الشركات" />
      <ReportView r={r} currency={s.currency} showCompanies />
    </div>
  );
}
