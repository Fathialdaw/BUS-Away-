import { sql } from "drizzle-orm";
import {
  boolean,
  date,
  integer,
  jsonb,
  pgTable,
  serial,
  text,
  timestamp,
  uniqueIndex,
} from "drizzle-orm/pg-core";

export const settings = pgTable("settings", {
  key: text("key").primaryKey(),
  value: text("value").notNull().default(""),
});

export const files = pgTable("files", {
  id: text("id").primaryKey(),
  mime: text("mime").notNull(),
  data: text("data").notNull(),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const states = pgTable("states", {
  id: serial("id").primaryKey(),
  name: text("name").notNull().unique(),
});

export const cities = pgTable("cities", {
  id: serial("id").primaryKey(),
  stateId: integer("state_id")
    .notNull()
    .references(() => states.id, { onDelete: "cascade" }),
  name: text("name").notNull(),
});

export const paymentTypes = pgTable("payment_types", {
  id: serial("id").primaryKey(),
  name: text("name").notNull().unique(),
  active: boolean("active").notNull().default(true),
});

export const companies = pgTable("companies", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  logo: text("logo"),
  phone: text("phone"),
  email: text("email"),
  address: text("address"),
  licenseNumber: text("license_number"),
  routes: text("routes"),
  status: text("status").notNull().default("pending"), // active | suspended | pending
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const companyAccounts = pgTable("company_accounts", {
  id: serial("id").primaryKey(),
  companyId: integer("company_id")
    .notNull()
    .references(() => companies.id),
  paymentType: text("payment_type").notNull(),
  accountName: text("account_name").notNull(),
  accountNumber: text("account_number").notNull(),
  bankName: text("bank_name"),
  status: text("status").notNull().default("active"), // active | disabled
});

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  phone: text("phone").notNull().unique(),
  email: text("email").unique(),
  password: text("password").notNull(),
  role: text("role").notNull(), // system_admin | company_manager | employee
  companyId: integer("company_id").references(() => companies.id),
  status: text("status").notNull().default("active"), // active | disabled
  permissions: jsonb("permissions").$type<string[]>().notNull().default([]),
  lastLoginAt: timestamp("last_login_at"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const passengers = pgTable("passengers", {
  id: serial("id").primaryKey(),
  passengerNumber: text("passenger_number").notNull().unique(),
  name: text("name").notNull(),
  phone: text("phone").notNull().unique(),
  nationalId: text("national_id"),
  state: text("state"),
  city: text("city"),
  email: text("email"),
  password: text("password").notNull(),
  avatar: text("avatar"),
  status: text("status").notNull().default("inactive"), // inactive | active | suspended
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const otps = pgTable("otps", {
  id: serial("id").primaryKey(),
  phone: text("phone").notNull(),
  code: text("code").notNull(),
  purpose: text("purpose").notNull(), // activate | login | reset
  expiresAt: timestamp("expires_at").notNull(),
  used: boolean("used").notNull().default(false),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const trips = pgTable("trips", {
  id: serial("id").primaryKey(),
  companyId: integer("company_id")
    .notNull()
    .references(() => companies.id),
  fromState: text("from_state").notNull(),
  fromCity: text("from_city").notNull(),
  toState: text("to_state").notNull(),
  toCity: text("to_city").notNull(),
  meetingPoint: text("meeting_point"),
  mapUrl: text("map_url"),
  departureDate: date("departure_date", { mode: "string" }).notNull(),
  departureTime: text("departure_time").notNull(),
  arrivalTime: text("arrival_time"),
  busType: text("bus_type").notNull().default("عادي"),
  totalSeats: integer("total_seats").notNull(),
  availableSeats: integer("available_seats").notNull(),
  price: integer("price").notNull(),
  status: text("status").notNull().default("open"),
  notes: text("notes"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const tripSeats = pgTable(
  "trip_seats",
  {
    id: serial("id").primaryKey(),
    tripId: integer("trip_id")
      .notNull()
      .references(() => trips.id, { onDelete: "cascade" }),
    seatNumber: integer("seat_number").notNull(),
    status: text("status").notNull().default("blocked"), // open | blocked
    updatedBy: integer("updated_by").references(() => users.id),
    updatedAt: timestamp("updated_at").notNull().defaultNow(),
  },
  (t) => [uniqueIndex("trip_seat_unique").on(t.tripId, t.seatNumber)],
);

export const bookings = pgTable(
  "bookings",
  {
    id: serial("id").primaryKey(),
    bookingNumber: text("booking_number").notNull().unique(),
    passengerId: integer("passenger_id")
      .notNull()
      .references(() => passengers.id),
    tripId: integer("trip_id")
      .notNull()
      .references(() => trips.id),
    companyId: integer("company_id")
      .notNull()
      .references(() => companies.id),
    seatNumber: integer("seat_number").notNull(),
    price: integer("price").notNull(),
    status: text("status").notNull().default("pending"),
    source: text("source").notNull().default("app"), // app | admin
    expiresAt: timestamp("expires_at"),
    createdAt: timestamp("created_at").notNull().defaultNow(),
  },
  (t) => [
    uniqueIndex("bookings_trip_seat_active")
      .on(t.tripId, t.seatNumber)
      .where(sql`${t.status} not in ('rejected','cancelled')`),
  ],
);

export const payments = pgTable("payments", {
  id: serial("id").primaryKey(),
  bookingId: integer("booking_id")
    .notNull()
    .references(() => bookings.id),
  companyAccountId: integer("company_account_id").references(() => companyAccounts.id),
  paymentMethod: text("payment_method").notNull(),
  transactionNumber: text("transaction_number"),
  transactionDate: text("transaction_date"),
  transactionTime: text("transaction_time"),
  amount: integer("amount").notNull(),
  receiptImage: text("receipt_image"),
  status: text("status").notNull().default("under_review"),
  note: text("note"),
  reviewedBy: integer("reviewed_by").references(() => users.id),
  reviewedAt: timestamp("reviewed_at"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const tickets = pgTable("tickets", {
  id: serial("id").primaryKey(),
  bookingId: integer("booking_id")
    .notNull()
    .unique()
    .references(() => bookings.id),
  ticketNumber: text("ticket_number").notNull().unique(),
  barcode: text("barcode").notNull(),
  qrCode: text("qr_code").notNull(),
  status: text("status").notNull().default("confirmed"),
  checkedAt: timestamp("checked_at"),
  checkedBy: integer("checked_by").references(() => users.id),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const notifications = pgTable(
  "notifications",
  {
    id: serial("id").primaryKey(),
    userId: integer("user_id").references(() => users.id),
    passengerId: integer("passenger_id").references(() => passengers.id),
    title: text("title").notNull(),
    message: text("message").notNull(),
    type: text("type").notNull().default("info"),
    refKey: text("ref_key"),
    isRead: boolean("is_read").notNull().default(false),
    isDismissed: boolean("is_dismissed").notNull().default(false),
    createdAt: timestamp("created_at").notNull().defaultNow(),
  },
  (t) => [uniqueIndex("notif_ref_unique").on(t.passengerId, t.refKey)],
);

export const chatRooms = pgTable("chat_rooms", {
  id: serial("id").primaryKey(),
  name: text("name"),
  isGroup: boolean("is_group").notNull().default(false),
  directKey: text("direct_key").unique(),
  createdBy: integer("created_by").references(() => users.id),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const chatMembers = pgTable(
  "chat_members",
  {
    id: serial("id").primaryKey(),
    roomId: integer("room_id")
      .notNull()
      .references(() => chatRooms.id, { onDelete: "cascade" }),
    userId: integer("user_id")
      .notNull()
      .references(() => users.id),
  },
  (t) => [uniqueIndex("chat_member_unique").on(t.roomId, t.userId)],
);

export const messages = pgTable("messages", {
  id: serial("id").primaryKey(),
  roomId: integer("room_id")
    .notNull()
    .references(() => chatRooms.id, { onDelete: "cascade" }),
  senderId: integer("sender_id")
    .notNull()
    .references(() => users.id),
  receiverId: integer("receiver_id").references(() => users.id),
  message: text("message").notNull().default(""),
  attachment: text("attachment"),
  isRead: boolean("is_read").notNull().default(false),
  reported: boolean("reported").notNull().default(false),
  reportReason: text("report_reason"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const auditLogs = pgTable("audit_logs", {
  id: serial("id").primaryKey(),
  userId: integer("user_id"),
  actorName: text("actor_name"),
  actorType: text("actor_type"),
  companyId: integer("company_id"),
  action: text("action").notNull(),
  entityType: text("entity_type"),
  entityId: text("entity_id"),
  oldData: jsonb("old_data"),
  newData: jsonb("new_data"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const expenses = pgTable("expenses", {
  id: serial("id").primaryKey(),
  companyId: integer("company_id")
    .notNull()
    .references(() => companies.id),
  tripId: integer("trip_id").references(() => trips.id),
  title: text("title").notNull(),
  amount: integer("amount").notNull(),
  expenseDate: date("expense_date", { mode: "string" }).notNull(),
  createdBy: integer("created_by").references(() => users.id),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const adminBookingRequests = pgTable("admin_booking_requests", {
  id: serial("id").primaryKey(),
  adminId: integer("admin_id")
    .notNull()
    .references(() => users.id),
  companyId: integer("company_id")
    .notNull()
    .references(() => companies.id),
  tripId: integer("trip_id")
    .notNull()
    .references(() => trips.id),
  passengerId: integer("passenger_id")
    .notNull()
    .references(() => passengers.id),
  seatNumber: integer("seat_number").notNull(),
  note: text("note"),
  status: text("status").notNull().default("pending"), // pending | approved | rejected
  decidedBy: integer("decided_by").references(() => users.id),
  decidedAt: timestamp("decided_at"),
  bookingId: integer("booking_id").references(() => bookings.id),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});
