import { eq, sql } from "drizzle-orm";
import { db } from "@/db";
import {
  adminBookingRequests,
  auditLogs,
  bookings,
  chatMembers,
  chatRooms,
  companies,
  companyAccounts,
  expenses,
  messages,
  notifications,
  otps,
  passengers,
  payments,
  tickets,
  tripSeats,
  trips,
  users,
} from "@/db/schema";
import { runSeedCore } from "@/lib/seed";

/**
 * تهيئة كاملة (لأغراض العرض):
 * تحذف بيانات التشغيل الحالية (الحجوزات والشركات وكل ما يترتب عليها)
 * ثم تعيد إنشاء حزمة البيانات التجريبية الأولى.
 * ملاحظة: يُعاد إنشاء المستخدمين بحساباتهم المعروفة، لذا تنتهي الجلسات الحالية.
 */
export async function reseedAll(): Promise<void> {
  await db.delete(adminBookingRequests);
  await db.delete(tickets);
  await db.delete(payments);
  await db.delete(bookings);
  await db.delete(tripSeats);
  await db.delete(expenses);
  await db.delete(messages);
  await db.delete(chatMembers);
  await db.delete(chatRooms);
  await db.delete(notifications);
  await db.delete(auditLogs);
  await db.delete(otps);
  await db.delete(users);
  await db.delete(trips);
  await db.delete(companyAccounts);
  await db.delete(companies);
  await db.delete(passengers);
  await runSeedCore();
}

/**
 * تهيئة محدودة (لأغراض العرض) لمدير المكتب:
 * تحذف حجوزات شركته ومدفوعاتها وتذاكرها وطلباتها ومصروفاتها،
 * ثم تفتح جميع مقاعد رحلاته وتعيد رحلاته الكاملة إلى "مفتوحة للحجز".
 * لا تمس بيانات الشركات الأخرى إطلاقاً.
 */
export async function reseedCompany(companyId: number): Promise<void> {
  await db.execute(sql`delete from tickets where booking_id in (select id from bookings where company_id = ${companyId})`);
  await db.execute(sql`delete from payments where booking_id in (select id from bookings where company_id = ${companyId})`);
  await db.execute(sql`delete from admin_booking_requests where company_id = ${companyId}`);
  await db.execute(sql`delete from bookings where company_id = ${companyId}`);
  await db.execute(sql`delete from trip_seats where trip_id in (select id from trips where company_id = ${companyId})`);
  await db.execute(sql`delete from expenses where company_id = ${companyId}`);
  await db.execute(
    sql`update trips set available_seats = total_seats, status = 'open'
         where company_id = ${companyId} and status in ('open','full','scheduled')`,
  );
  const myTrips = await db.select({ id: trips.id, total: trips.totalSeats }).from(trips).where(eq(trips.companyId, companyId));
  if (myTrips.length)
    await db.insert(tripSeats).values(
      myTrips.flatMap((t) => Array.from({ length: t.total }, (_, i) => ({ tripId: t.id, seatNumber: i + 1, status: "open" }))),
    );
}

/** حذف جميع الرحلات والحجوزات لكل النظام — لمدير النظام فقط */
export async function clearTripsAndBookingsAll(): Promise<void> {
  await db.delete(adminBookingRequests);
  await db.delete(tickets);
  await db.delete(payments);
  await db.delete(bookings);
  await db.delete(tripSeats);
  await db.delete(expenses);
  await db.delete(trips);
}

/** حذف رحلات وحجوزات شركة واحدة — لمدير المكتب على شركته فقط */
export async function clearTripsAndBookingsCompany(companyId: number): Promise<void> {
  await db.execute(sql`delete from admin_booking_requests where company_id = ${companyId}`);
  await db.execute(sql`delete from tickets where booking_id in (select id from bookings where company_id = ${companyId})`);
  await db.execute(sql`delete from payments where booking_id in (select id from bookings where company_id = ${companyId})`);
  await db.execute(sql`delete from bookings where company_id = ${companyId}`);
  await db.execute(sql`delete from trip_seats where trip_id in (select id from trips where company_id = ${companyId})`);
  await db.execute(sql`delete from expenses where company_id = ${companyId}`);
  await db.execute(sql`delete from trips where company_id = ${companyId}`);
}
