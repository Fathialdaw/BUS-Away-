export type Tone = "green" | "red" | "amber" | "blue" | "gray" | "teal" | "orange" | "purple";
type SM = Record<string, { label: string; tone: Tone }>;

export const bookingStatus: SM = {
  pending: { label: "حجز قيد الانتظار", tone: "amber" },
  awaiting_payment: { label: "بانتظار تأكيد الدفع", tone: "blue" },
  confirmed: { label: "مؤكد", tone: "green" },
  rejected: { label: "مرفوض", tone: "red" },
  cancelled: { label: "ملغي", tone: "gray" },
  completed: { label: "مكتمل", tone: "teal" },
  no_show: { label: "لم يحضر الراكب", tone: "orange" },
};
export const paymentStatus: SM = {
  under_review: { label: "قيد المراجعة", tone: "blue" },
  accepted: { label: "مقبول", tone: "green" },
  rejected: { label: "مرفوض", tone: "red" },
  needs_edit: { label: "يحتاج إلى تعديل", tone: "amber" },
  incomplete: { label: "غير مكتمل", tone: "gray" },
  refunded: { label: "مسترد", tone: "purple" },
};
export const tripStatus: SM = {
  scheduled: { label: "مجدولة", tone: "gray" },
  open: { label: "مفتوحة للحجز", tone: "green" },
  full: { label: "مكتملة المقاعد", tone: "orange" },
  started: { label: "بدأت", tone: "blue" },
  ended: { label: "انتهت", tone: "teal" },
  cancelled: { label: "ملغاة", tone: "red" },
  postponed: { label: "مؤجلة", tone: "amber" },
};
export const ticketStatus: SM = {
  issued: { label: "صادرة", tone: "blue" },
  confirmed: { label: "مؤكدة", tone: "green" },
  used: { label: "مستخدمة", tone: "teal" },
  cancelled: { label: "ملغاة", tone: "gray" },
  expired: { label: "منتهية", tone: "gray" },
  no_show: { label: "لم يحضر الراكب", tone: "orange" },
};
export const companyStatus: SM = {
  active: { label: "نشطة", tone: "green" },
  suspended: { label: "موقوفة", tone: "red" },
  pending: { label: "قيد المراجعة", tone: "amber" },
};
export const passengerStatus: SM = {
  inactive: { label: "غير مفعل", tone: "amber" },
  active: { label: "مفعل", tone: "green" },
  suspended: { label: "موقوف", tone: "red" },
};
export const userStatus: SM = {
  active: { label: "نشط", tone: "green" },
  disabled: { label: "معطل", tone: "red" },
};
export const accountStatus: SM = {
  active: { label: "فعال", tone: "green" },
  disabled: { label: "معطل", tone: "gray" },
};
export const requestStatus: SM = {
  pending: { label: "بانتظار موافقة مدير المكتب", tone: "amber" },
  approved: { label: "تمت الموافقة", tone: "green" },
  rejected: { label: "مرفوض", tone: "red" },
};
export const roleLabel: Record<string, string> = {
  system_admin: "مدير النظام",
  company_manager: "مدير المكتب",
  employee: "موظف",
};
export const BUS_TYPES = ["سياحي", "VIP", "عادي", "ميني باص", "نوم (سليبر)"];
export const PERMS = [
  { key: "bookings", label: "عرض الحجوزات" },
  { key: "payments", label: "مراجعة المدفوعات" },
  { key: "scan", label: "فحص التذاكر" },
  { key: "trips", label: "عرض الرحلات" },
];

export function info(map: SM, key: string | null | undefined) {
  return map[key ?? ""] ?? { label: key ?? "-", tone: "gray" as Tone };
}

const TZ = "Africa/Khartoum";
export function todayStr(d = new Date()): string {
  return new Intl.DateTimeFormat("en-CA", { timeZone: TZ }).format(d);
}
export function depAt(date: string, time: string): Date {
  return new Date(`${date}T${time.length === 5 ? time : time.slice(0, 5)}:00+02:00`);
}
export function fmtDate(d: string | Date | null | undefined): string {
  if (!d) return "-";
  const dt = typeof d === "string" ? new Date(`${d.slice(0, 10)}T12:00:00+02:00`) : d;
  return new Intl.DateTimeFormat("ar-u-nu-latn", {
    day: "numeric",
    month: "long",
    year: "numeric",
    timeZone: TZ,
  }).format(dt);
}
export function fmtTime(t: string | null | undefined): string {
  if (!t) return "-";
  const [h, m] = t.split(":").map(Number);
  const suffix = h < 12 ? "صباحاً" : "مساءً";
  const hh = h % 12 === 0 ? 12 : h % 12;
  return `${String(hh).padStart(2, "0")}:${String(m).padStart(2, "0")} ${suffix}`;
}
export function fmtDateTime(d: Date | null | undefined): string {
  if (!d) return "-";
  return new Intl.DateTimeFormat("ar-u-nu-latn", {
    day: "numeric",
    month: "short",
    year: "numeric",
    hour: "2-digit",
    minute: "2-digit",
    timeZone: TZ,
  }).format(d);
}
export function money(n: number | null | undefined, cur = "ج.س"): string {
  return `${Number(n ?? 0).toLocaleString("en-US")} ${cur}`;
}
export function digits(n: number): string {
  let s = "";
  for (let i = 0; i < n; i++) s += Math.floor(Math.random() * 10);
  return s;
}
export function str(v: FormDataEntryValue | null | undefined): string {
  return typeof v === "string" ? v.trim() : "";
}
export function num(v: FormDataEntryValue | null | undefined): number {
  const n = Number(str(v));
  return Number.isFinite(n) ? n : 0;
}
export function one(v: string | string[] | undefined): string {
  return Array.isArray(v) ? (v[0] ?? "") : (v ?? "");
}
