import { and, desc, eq, ilike, or, type SQL } from "drizzle-orm";
import { db } from "@/db";
import { bookings, companies, passengers, payments, trips } from "@/db/schema";

export async function listBookings(f: { companyId?: number; status?: string; q?: string; payStatus?: string; limit?: number }) {
  const conds: SQL[] = [];
  if (f.companyId) conds.push(eq(bookings.companyId, f.companyId));
  if (f.status) conds.push(eq(bookings.status, f.status));
  if (f.payStatus) conds.push(eq(payments.status, f.payStatus));
  if (f.q) {
    const like = `%${f.q}%`;
    conds.push(
      or(
        ilike(bookings.bookingNumber, like),
        ilike(passengers.name, like),
        ilike(passengers.phone, like),
        ilike(passengers.passengerNumber, like),
        ilike(payments.transactionNumber, like),
      )!,
    );
  }
  return db
    .select({ b: bookings, pax: passengers, t: trips, c: companies, pay: payments })
    .from(bookings)
    .innerJoin(passengers, eq(passengers.id, bookings.passengerId))
    .innerJoin(trips, eq(trips.id, bookings.tripId))
    .innerJoin(companies, eq(companies.id, bookings.companyId))
    .leftJoin(payments, eq(payments.bookingId, bookings.id))
    .where(conds.length ? and(...conds) : undefined)
    .orderBy(desc(bookings.id))
    .limit(f.limit ?? 150);
}

export type BookingRow = Awaited<ReturnType<typeof listBookings>>[number];
