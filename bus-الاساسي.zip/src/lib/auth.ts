import crypto from "node:crypto";
import { cookies } from "next/headers";
import { redirect } from "next/navigation";
import { and, eq } from "drizzle-orm";
import { db } from "@/db";
import { companies, passengers, users } from "@/db/schema";
export { hashPassword, verifyPassword } from "@/lib/password";

export type Realm = "passenger" | "company" | "admin";
const NAMES: Record<Realm, string> = {
  passenger: "pax_session",
  company: "co_session",
  admin: "adm_session",
};

function sign(v: string) {
  const secret = process.env.SESSION_SECRET || "dev-secret-bus-booking-2026";
  return crypto.createHmac("sha256", secret).update(v).digest("base64url");
}

export async function setSession(realm: Realm, id: number) {
  const exp = Date.now() + 30 * 864e5;
  const v = `${id}.${exp}`;
  (await cookies()).set(NAMES[realm], `${v}.${sign(v)}`, {
    httpOnly: true,
    sameSite: "lax",
    path: "/",
    maxAge: 30 * 86400,
  });
}

export async function clearSession(realm: Realm) {
  (await cookies()).delete(NAMES[realm]);
}

export async function readSessionId(realm: Realm): Promise<number | null> {
  const c = (await cookies()).get(NAMES[realm])?.value;
  if (!c) return null;
  const [id, exp, sig] = c.split(".");
  if (!id || !exp || !sig) return null;
  const expected = Buffer.from(sign(`${id}.${exp}`));
  const given = Buffer.from(sig);
  if (expected.length !== given.length || !crypto.timingSafeEqual(expected, given)) return null;
  if (Number(exp) < Date.now()) return null;
  return Number(id);
}

export async function anySession(): Promise<boolean> {
  for (const r of ["passenger", "company", "admin"] as Realm[]) {
    if (await readSessionId(r)) return true;
  }
  return false;
}

export async function getPassenger() {
  const id = await readSessionId("passenger");
  if (!id) return null;
  const [p] = await db.select().from(passengers).where(eq(passengers.id, id));
  if (!p || p.status !== "active") return null;
  return p;
}

export async function requirePassenger() {
  const p = await getPassenger();
  if (!p) redirect("/passenger/login");
  return p;
}

export type StaffUser = typeof users.$inferSelect;
export type Company = typeof companies.$inferSelect;

export async function getCompanyContext(): Promise<{ user: StaffUser; company: Company } | null> {
  const id = await readSessionId("company");
  if (!id) return null;
  const [u] = await db.select().from(users).where(and(eq(users.id, id), eq(users.status, "active")));
  if (!u || !u.companyId || (u.role !== "company_manager" && u.role !== "employee")) return null;
  const [c] = await db.select().from(companies).where(eq(companies.id, u.companyId));
  if (!c || c.status === "suspended") return null;
  return { user: u, company: c };
}

export async function requireCompany() {
  const ctx = await getCompanyContext();
  if (!ctx) redirect("/company/login");
  return ctx;
}

export async function requireAdmin() {
  const id = await readSessionId("admin");
  if (!id) redirect("/admin/login");
  const [u] = await db
    .select()
    .from(users)
    .where(and(eq(users.id, id), eq(users.status, "active"), eq(users.role, "system_admin")));
  if (!u) redirect("/admin/login");
  return u;
}

export function can(user: StaffUser, perm: string): boolean {
  return user.role === "company_manager" || (user.permissions ?? []).includes(perm);
}

export function isManager(user: StaffUser): boolean {
  return user.role === "company_manager";
}
