import { count, sql } from "drizzle-orm";
import { db } from "@/db";
import {
  bookings,
  chatMembers,
  chatRooms,
  cities,
  companies,
  companyAccounts,
  expenses,
  messages,
  notifications,
  passengers,
  paymentTypes,
  payments,
  states,
  tickets,
  trips,
  tripSeats,
  users,
} from "@/db/schema";
import { hashPassword } from "@/lib/password";

const g = globalThis as typeof globalThis & { __seedP?: Promise<void> };

export function ensureSeed(): Promise<void> {
  if (!g.__seedP) {
    g.__seedP = runSeed().catch((e) => {
      g.__seedP = undefined;
      throw e;
    });
  }
  return g.__seedP;
}

const GEO: Record<string, string[]> = {
  الخرطوم: ["الخرطوم", "أم درمان", "بحري", "الخرطوم بحري"],
  الجزيرة: ["ود مدني", "الحصاحيصا", "المناقل"],
  "نهر النيل": ["عطبرة", "الدامر", "شندي"],
  الشمالية: ["دنقلا", "مروي", "وادي حلفا"],
  كسلا: ["كسلا", "خشم القربة"],
  القضارف: ["القضارف", "الشواك"],
  "البحر الأحمر": ["بورتسودان", "سواكن", "طوكر"],
  سنار: ["سنار", "سنجة"],
  "النيل الأبيض": ["كوستي", "ربك", "الدويم"],
  "النيل الأزرق": ["الدمازين"],
  "شمال كردفان": ["الأبيض", "بارا"],
  "جنوب كردفان": ["كادقلي"],
  "غرب كردفان": ["الفولة"],
  "شمال دارفور": ["الفاشر"],
  "جنوب دارفور": ["نيالا"],
  "وسط دارفور": ["زالنجي"],
  "شرق دارفور": ["الضعين"],
  "غرب دارفور": ["الجنينة"],
};

const day = (n: number) =>
  new Intl.DateTimeFormat("en-CA", { timeZone: "Africa/Khartoum" }).format(new Date(Date.now() + n * 864e5));

async function runSeed() {
  const [r] = await db.select({ c: count() }).from(users);
  if (r.c > 0) return;
  await runSeedCore();
}

/** نواة البيانات التجريبية — تُستدعى عند التهيئة الأولى وعند إعادة التهيئة من لوحة الإدارة */
export async function runSeedCore() {
  const [st0] = await db.select({ c: count() }).from(states);
  if (st0.c === 0) {
    // الولايات والمدن
    for (const [s, cs] of Object.entries(GEO)) {
      const [row] = await db.insert(states).values({ name: s }).returning();
      await db.insert(cities).values(cs.map((name) => ({ stateId: row.id, name })));
    }
  }
  const [pt0] = await db.select({ c: count() }).from(paymentTypes);
  if (pt0.c === 0) {
    await db.insert(paymentTypes).values([
      { name: "بنكك" },
      { name: "أوكاش" },
      { name: "فوري" },
      { name: "تحويل بنكي مباشر" },
    ]);
  }

  // الشركات
  const cos = await db
    .insert(companies)
    .values([
      {
        name: "شركة النيل للنقل",
        phone: "0911111111",
        email: "nile@bus.sd",
        address: "الخرطوم - الموقف الجديد",
        licenseNumber: "NL-2020-114",
        routes: "الخرطوم، الجزيرة، سنار، النيل الأبيض",
        status: "active",
      },
      {
        name: "شركة السلام للسفر",
        phone: "0922222222",
        email: "salam@bus.sd",
        address: "أم درمان - محطة الشهداء",
        licenseNumber: "SL-2018-052",
        routes: "الخرطوم، نهر النيل، البحر الأحمر، كسلا",
        status: "active",
      },
      {
        name: "شركة الأمان للنقل",
        phone: "0933333333",
        email: "aman@bus.sd",
        address: "بحري - الشعبية",
        licenseNumber: "AM-2024-007",
        routes: "الخرطوم، شمال كردفان",
        status: "pending",
      },
    ])
    .returning();
  await db.insert(companyAccounts).values([
    { companyId: cos[0].id, paymentType: "بنكك", accountName: "شركة النيل للنقل", accountNumber: "1234567", bankName: "بنك الخرطوم" },
    { companyId: cos[0].id, paymentType: "أوكاش", accountName: "شركة النيل للنقل", accountNumber: "0911111111", bankName: "أوكاش" },
    { companyId: cos[0].id, paymentType: "تحويل بنكي مباشر", accountName: "شركة النيل للنقل المحدودة", accountNumber: "SD-0045-778899", bankName: "بنك فيصل الإسلامي" },
    { companyId: cos[1].id, paymentType: "بنكك", accountName: "شركة السلام للسفر", accountNumber: "7654321", bankName: "بنك الخرطوم" },
    { companyId: cos[1].id, paymentType: "فوري", accountName: "السلام للسفر", accountNumber: "5551234", bankName: "فوري" },
  ]);

  // المستخدمون
  const pwAdmin = hashPassword("admin123");
  const pwMgr = hashPassword("manager123");
  const pwEmp = hashPassword("emp123");
  const us = await db
    .insert(users)
    .values([
      { name: "مدير النظام", phone: "0900000000", email: "admin@bus.sd", password: pwAdmin, role: "system_admin" },
      { name: "عبدالله الصادق", phone: "0911111110", email: "nile.manager@bus.sd", password: pwMgr, role: "company_manager", companyId: cos[0].id },
      { name: "منى خالد", phone: "0911111112", email: "nile.emp@bus.sd", password: pwEmp, role: "employee", companyId: cos[0].id, permissions: ["bookings", "payments", "scan", "trips"] },
      { name: "يوسف آدم", phone: "0922222220", email: "salam.manager@bus.sd", password: pwMgr, role: "company_manager", companyId: cos[1].id },
      { name: "إسراء محمد", phone: "0922222223", email: "salam.emp@bus.sd", password: pwEmp, role: "employee", companyId: cos[1].id, permissions: ["bookings", "scan"] },
    ])
    .returning();

  // الركاب
  const paxPw = hashPassword("pass123");
  const paxData: [string, string, string, string][] = [
    ["أحمد محمد علي", "0912345678", "الخرطوم", "الخرطوم"],
    ["فاطمة عثمان", "0923456789", "الجزيرة", "ود مدني"],
    ["محمود إبراهيم", "0911223344", "نهر النيل", "عطبرة"],
    ["سارة الطيب", "0999887766", "كسلا", "كسلا"],
    ["عمر حسن", "0922334455", "الخرطوم", "أم درمان"],
    ["هدى يوسف", "0966778899", "البحر الأحمر", "بورتسودان"],
  ];
  const pax = await db
    .insert(passengers)
    .values(
      paxData.map(([name, phone, state, city], i) => ({
        passengerNumber: `P${100001 + i}`,
        name,
        phone,
        state,
        city,
        nationalId: `1${String(10000000 + i * 7919)}`,
        password: paxPw,
        status: "active",
      })),
    )
    .returning();

  // الرحلات
  type T = [number, string, string, string, string, number, string, string, string, number, number, string, string];
  const defs: T[] = [
    [0, "الخرطوم", "الخرطوم", "الجزيرة", "ود مدني", 1, "08:00", "11:00", "سياحي", 40, 9000, "open", "موقف الخرطوم الجديد - بوابة 3"],
    [0, "الخرطوم", "الخرطوم", "سنار", "سنار", 2, "07:00", "11:30", "VIP", 28, 13000, "open", "موقف الخرطوم الجديد - بوابة 1"],
    [0, "الخرطوم", "الخرطوم", "النيل الأبيض", "كوستي", 3, "09:30", "13:30", "عادي", 44, 7000, "open", "موقف جاكسون"],
    [0, "الجزيرة", "ود مدني", "الخرطوم", "الخرطوم", 3, "15:00", "18:00", "سياحي", 40, 9000, "open", "محطة ود مدني الرئيسية"],
    [0, "الخرطوم", "الخرطوم", "الجزيرة", "ود مدني", 5, "08:00", "11:00", "سياحي", 40, 9500, "open", "موقف الخرطوم الجديد - بوابة 3"],
    [0, "الخرطوم", "الخرطوم", "سنار", "سنجة", 9, "06:30", "12:00", "ميني باص", 18, 14000, "open", "موقف الخرطوم الجديد"],
    [0, "الخرطوم", "الخرطوم", "الجزيرة", "ود مدني", 12, "20:00", "23:00", "نوم (سليبر)", 24, 15000, "postponed", "موقف الخرطوم الجديد"],
    [1, "الخرطوم", "أم درمان", "البحر الأحمر", "بورتسودان", 1, "18:00", "05:00", "VIP", 32, 30000, "open", "محطة الشهداء - أم درمان"],
    [1, "الخرطوم", "الخرطوم", "نهر النيل", "عطبرة", 2, "10:00", "14:00", "سياحي", 40, 11000, "open", "موقف شروني"],
    [1, "الخرطوم", "الخرطوم", "كسلا", "كسلا", 4, "17:00", "02:00", "سياحي", 40, 22000, "open", "موقف شروني"],
    [1, "نهر النيل", "عطبرة", "الخرطوم", "الخرطوم", 6, "07:00", "11:00", "عادي", 44, 10000, "open", "موقف عطبرة"],
    [1, "الخرطوم", "الخرطوم", "الشمالية", "دنقلا", 8, "05:30", "17:30", "VIP", 28, 35000, "open", "محطة الشهداء - أم درمان"],
    [1, "الخرطوم", "أم درمان", "البحر الأحمر", "بورتسودان", 14, "18:30", "05:30", "VIP", 32, 31000, "open", "محطة الشهداء - أم درمان"],
  ];
  const past: T[] = [];
  for (let i = 0; i < 16; i++) {
    const co = i % 2;
    const base = defs.filter((d) => d[0] === co)[i % 5];
    past.push([co, base[1], base[2], base[3], base[4], -(i + 1) * 2, base[6], base[7], base[8], base[9], base[10], i === 5 ? "cancelled" : "ended", base[12]]);
  }
  const all = [...defs, ...past];
  const tr = await db
    .insert(trips)
    .values(
      all.map((d) => ({
        companyId: cos[d[0]].id,
        fromState: d[1],
        fromCity: d[2],
        toState: d[3],
        toCity: d[4],
        departureDate: day(d[5]),
        departureTime: d[6],
        arrivalTime: d[7],
        busType: d[8],
        totalSeats: d[9],
        availableSeats: d[9],
        price: d[10],
        status: d[11],
        meetingPoint: d[12],
        mapUrl: "https://maps.google.com/?q=15.5007,32.5599",
        notes: "يرجى الحضور قبل موعد المغادرة بساعة. الأمتعة المسموحة: حقيبة واحدة لكل راكب.",
      })),
    )
    .returning();

  // افتح جميع مقاعد الرحلات التجريبية
  await db
    .insert(tripSeats)
    .values(
      tr.flatMap((t) => Array.from({ length: t.totalSeats }, (_, i) => ({ tripId: t.id, seatNumber: i + 1, status: "open" }))),
    );

  // الحجوزات
  type B = { t: number; p: number; seat: number; status: string; pay: "accepted" | "under_review"; at: Date; method: string };
  const bs: B[] = [];
  const methods = ["بنكك", "أوكاش", "فوري", "تحويل بنكي مباشر"];
  const used = new Set<string>();
  const add = (b: B) => {
    const k = `${b.t}:${b.seat}`;
    if (used.has(k)) return false;
    used.add(k);
    bs.push(b);
    return true;
  };
  // حجوزات الراكب التجريبي
  add({ t: 0, p: 0, seat: 12, status: "confirmed", pay: "accepted", at: new Date(Date.now() - 864e5), method: "بنكك" });
  add({ t: 1, p: 0, seat: 5, status: "awaiting_payment", pay: "under_review", at: new Date(Date.now() - 36e5), method: "أوكاش" });
  add({ t: 2, p: 1, seat: 8, status: "awaiting_payment", pay: "under_review", at: new Date(Date.now() - 72e5), method: "بنكك" });
  add({ t: 7, p: 1, seat: 3, status: "awaiting_payment", pay: "under_review", at: new Date(Date.now() - 18e5), method: "بنكك" });
  all.forEach((d, ti) => {
    const isPast = d[5] < 0;
    if (d[11] === "postponed") return;
    const n = isPast ? Math.floor(d[9] * (0.45 + ((ti * 37) % 50) / 100)) : 2 + ((ti * 3) % 9);
    for (let s = 0; s < n; s++) {
      const seat = 1 + ((s * 7 + ti) % d[9]);
      add({
        t: ti,
        p: (s + ti) % pax.length,
        seat,
        status: isPast ? (d[11] === "cancelled" ? "cancelled" : s % 11 === 0 ? "no_show" : "completed") : "confirmed",
        pay: "accepted",
        at: new Date(Date.now() + (d[5] - 3 - (s % 4)) * 864e5),
        method: methods[(s + ti) % 4],
      });
    }
  });
  const bkRows = await db
    .insert(bookings)
    .values(
      bs.map((b, i) => ({
        bookingNumber: `BK-${day(0).replace(/-/g, "")}-${String(i + 1).padStart(4, "0")}`,
        passengerId: pax[b.p].id,
        tripId: tr[b.t].id,
        companyId: tr[b.t].companyId,
        seatNumber: b.seat,
        price: tr[b.t].price,
        status: b.status,
        createdAt: b.at,
      })),
    )
    .returning();
  await db.insert(payments).values(
    bkRows
      .map((b, i) => ({ b, d: bs[i] }))
      .filter(({ d }) => d.status !== "cancelled")
      .map(({ b, d }) => ({
        bookingId: b.id,
        paymentMethod: d.method,
        transactionNumber: `TX${100000 + b.id * 13}`,
        transactionDate: day(0),
        transactionTime: "10:15",
        amount: b.price,
        status: d.pay,
        createdAt: d.at,
        reviewedAt: d.pay === "accepted" ? d.at : null,
      })),
  );
  const tk = bkRows
    .map((b, i) => ({ b, d: bs[i] }))
    .filter(({ d }) => ["confirmed", "completed", "no_show"].includes(d.status));
  await db.insert(tickets).values(
    tk.map(({ b, d }) => ({
      bookingId: b.id,
      ticketNumber: `TK-${String(10000000 + b.id * 97).slice(0, 8)}`,
      barcode: `${10000000 + b.id * 97}`,
      qrCode: `TK-${String(10000000 + b.id * 97).slice(0, 8)}`,
      status: d.status === "completed" ? "used" : d.status === "no_show" ? "no_show" : "confirmed",
      createdAt: d.at,
    })),
  );
  await db.execute(sql`update trips set available_seats = total_seats - (select count(*) from bookings b where b.trip_id = trips.id and b.status not in ('rejected','cancelled'))`);

  // مصروفات
  const exp: (typeof expenses.$inferInsert)[] = [];
  for (let i = 0; i < 12; i++) {
    exp.push({ companyId: cos[i % 2].id, title: ["وقود", "صيانة", "رواتب سائقين", "رسوم موقف"][i % 4], amount: 40000 + i * 7000, expenseDate: day(-i * 3 - 1) });
  }
  await db.insert(expenses).values(exp);

  // إشعارات
  await db.insert(notifications).values([
    { passengerId: pax[0].id, title: "مرحباً بك", message: "تم تفعيل حسابك بنجاح. يمكنك الآن حجز رحلتك الأولى.", type: "info" },
  ]);

  // دردشة المديرين
  const [room] = await db.insert(chatRooms).values({ name: "منسقو المكاتب", isGroup: true, createdBy: us[1].id }).returning();
  await db.insert(chatMembers).values([
    { roomId: room.id, userId: us[1].id },
    { roomId: room.id, userId: us[3].id },
  ]);
  await db.insert(messages).values([
    { roomId: room.id, senderId: us[1].id, message: "السلام عليكم، ما هو سعر تذكرة الخرطوم - بورتسودان عندكم هذا الأسبوع؟" },
    { roomId: room.id, senderId: us[3].id, message: "وعليكم السلام، 30,000 جنيه للـ VIP. هل ننسق الأسعار في الخطوط المشتركة؟" },
  ]);
}
