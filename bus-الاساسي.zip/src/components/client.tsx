"use client";

import Link from "next/link";
import { usePathname, useRouter } from "next/navigation";
import { useEffect, useRef, useState, type ReactNode } from "react";

export type NavItem = { href: string; label: string; icon?: string; exact?: boolean };

export function NavLinks({ items, variant }: { items: NavItem[]; variant: "bottom" | "side" | "scroll" }) {
  const path = usePathname();
  const active = (i: NavItem) => (i.exact ? path === i.href : path === i.href || path.startsWith(i.href + "/"));
  if (variant === "bottom")
    return (
      <nav className="no-print fixed inset-x-0 bottom-0 z-30 border-t border-slate-200 bg-white pb-[env(safe-area-inset-bottom)]">
        <div className="mx-auto grid max-w-3xl grid-cols-5">
          {items.map((i) => (
            <Link
              key={i.href}
              href={i.href}
              className={`flex flex-col items-center gap-0.5 py-2 text-[11px] font-semibold ${active(i) ? "text-primary" : "text-slate-500"}`}
            >
              <span className="text-xl leading-none">{i.icon}</span>
              {i.label}
            </Link>
          ))}
        </div>
      </nav>
    );
  if (variant === "side")
    return (
      <nav className="space-y-1">
        {items.map((i) => (
          <Link
            key={i.href}
            href={i.href}
            className={`flex items-center gap-2 rounded-xl px-3 py-2.5 text-sm font-semibold transition ${active(i) ? "bg-primary text-white" : "text-slate-600 hover:bg-slate-100"}`}
          >
            <span>{i.icon}</span>
            {i.label}
          </Link>
        ))}
      </nav>
    );
  return (
    <nav className="no-print flex gap-2 overflow-x-auto pb-1">
      {items.map((i) => (
        <Link
          key={i.href}
          href={i.href}
          className={`whitespace-nowrap rounded-full px-3 py-1.5 text-xs font-semibold ${active(i) ? "bg-primary text-white" : "bg-white text-slate-600 ring-1 ring-slate-200"}`}
        >
          {i.icon} {i.label}
        </Link>
      ))}
    </nav>
  );
}

export function PrintButton({ label = "🖨️ طباعة / حفظ PDF" }: { label?: string }) {
  return (
    <button
      type="button"
      onClick={() => window.print()}
      className="no-print inline-flex cursor-pointer items-center justify-center gap-1 rounded-xl border border-slate-300 bg-white px-4 py-2.5 text-sm font-semibold text-slate-700 hover:bg-slate-50"
    >
      {label}
    </button>
  );
}

export function AutoRefresh({ seconds = 8 }: { seconds?: number }) {
  const router = useRouter();
  useEffect(() => {
    const t = setInterval(() => router.refresh(), seconds * 1000);
    return () => clearInterval(t);
  }, [router, seconds]);
  return null;
}

export function ConfirmButton({
  message,
  className,
  children,
}: {
  message: string;
  className?: string;
  children: ReactNode;
}) {
  return (
    <button
      type="submit"
      className={className}
      onClick={(e) => {
        if (!confirm(message)) e.preventDefault();
      }}
    >
      {children}
    </button>
  );
}

async function shrink(file: File, square?: number): Promise<{ blob: Blob; name: string }> {
  if (!file.type.startsWith("image/") || (file.type === "image/gif" && !square)) return { blob: file, name: file.name };
  const bmp = await createImageBitmap(file);
  const c = document.createElement("canvas");
  if (square) {
    // قص مركزي إلى مربع بحجم ثابت (للشعار والأيقونة)
    c.width = square;
    c.height = square;
    const side = Math.min(bmp.width, bmp.height);
    c.getContext("2d")!.drawImage(bmp, (bmp.width - side) / 2, (bmp.height - side) / 2, side, side, 0, 0, square, square);
    const blob: Blob = await new Promise((res) => c.toBlob((b) => res(b ?? file), "image/png"));
    return { blob, name: "icon.png" };
  }
  const max = 1400;
  const k = Math.min(1, max / Math.max(bmp.width, bmp.height));
  c.width = Math.round(bmp.width * k);
  c.height = Math.round(bmp.height * k);
  c.getContext("2d")!.drawImage(bmp, 0, 0, c.width, c.height);
  const blob: Blob = await new Promise((res) => c.toBlob((b) => res(b ?? file), "image/jpeg", 0.82));
  return { blob, name: file.name };
}

export function FileUpload({
  name,
  label,
  initial,
  accept = "image/*",
  square,
  removable,
  hint,
}: {
  name: string;
  label: string;
  initial?: string | null;
  accept?: string;
  /** عند التحديد تُقص الصورة إلى مربع بهذا الحجم (px) وتُحفظ PNG */
  square?: number;
  removable?: boolean;
  hint?: string;
}) {
  const [url, setUrl] = useState(initial ?? "");
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState("");
  async function onChange(e: React.ChangeEvent<HTMLInputElement>) {
    const f = e.target.files?.[0];
    if (!f) return;
    setBusy(true);
    setErr("");
    try {
      const { blob, name: fname } = await shrink(f, square);
      const fd = new FormData();
      fd.append("file", blob, fname);
      const r = await fetch("/api/upload", { method: "POST", body: fd });
      const j = await r.json();
      if (!r.ok) throw new Error(j.error || "فشل الرفع");
      setUrl(j.url);
    } catch (e2) {
      setErr(e2 instanceof Error ? e2.message : "فشل الرفع");
    }
    setBusy(false);
  }
  const isImg = url && !url.endsWith(".pdf");
  return (
    <div>
      <span className="mb-1 block text-xs font-semibold text-slate-600">{label}</span>
      <input type="hidden" name={name} value={url} />
      <div className="flex items-center gap-3 rounded-xl border border-dashed border-slate-300 bg-white p-3">
        {isImg && (
          // eslint-disable-next-line @next/next/no-img-element
          <img src={url} alt="" className={`h-20 w-20 border bg-slate-50 object-cover ${square ? "rounded-2xl" : "rounded-lg"}`} />
        )}
        <div className="flex-1">
          <input type="file" accept={accept} onChange={onChange} className="w-full text-xs file:ml-2 file:rounded-lg file:border-0 file:bg-primary/10 file:px-3 file:py-1.5 file:text-xs file:font-semibold file:text-primary" />
          {hint && <p className="mt-1 text-[11px] text-slate-400">{hint}</p>}
          {busy && <p className="mt-1 text-xs text-slate-500">جاري الرفع...</p>}
          {!busy && url && <p className="mt-1 text-xs text-emerald-600">✔ تم اختيار الصورة — اضغط «حفظ» لتطبيقها</p>}
          {err && <p className="mt-1 text-xs text-red-600">{err}</p>}
          {removable && url && !busy && (
            <button type="button" onClick={() => setUrl("")} className="mt-1 cursor-pointer text-xs font-semibold text-red-600">
              إزالة الصورة
            </button>
          )}
        </div>
      </div>
    </div>
  );
}

export type SeatInfo = { n: number; state: "open" | "booked" | "locked" };

export function SeatPicker({
  total,
  states,
  tripId,
  action,
  priceLabel,
}: {
  total: number;
  states: SeatInfo[];
  tripId: number;
  action: (fd: FormData) => Promise<void>;
  priceLabel: string;
}) {
  const [sel, setSel] = useState<number | null>(null);
  const map = new Map(states.map((s) => [s.n, s.state]));
  const openCount = states.filter((s) => s.state === "open").length;
  const rows: number[][] = [];
  for (let r = 0; r * 4 < total; r++) rows.push([r * 4 + 1, r * 4 + 2, r * 4 + 3, r * 4 + 4]);
  const cell = "flex h-12 flex-col items-center justify-center rounded-lg border text-sm font-bold leading-none";
  const seat = (n: number) => {
    if (n > total) return <div key={n} />;
    const st = map.get(n) ?? "locked";
    if (st === "booked")
      return (
        <div key={n} title="محجوز" className={`${cell} cursor-not-allowed border-slate-500 bg-slate-700 text-white`}>
          {n}
        </div>
      );
    if (st === "locked")
      return (
        <div key={n} title="محجوزة من الشركة" className={`${cell} cursor-not-allowed border-slate-200 bg-slate-100 text-slate-400`}>
          {n}
          <span className="mt-0.5 text-[10px]">🔒</span>
        </div>
      );
    return (
      <button
        key={n}
        type="button"
        onClick={() => setSel(sel === n ? null : n)}
        className={`${cell} transition ${
          sel === n ? "border-primary bg-primary text-white shadow" : "border-emerald-400 bg-emerald-50 text-slate-800 hover:border-primary hover:bg-primary/10"
        }`}
      >
        {n}
      </button>
    );
  };
  return (
    <form action={action}>
      <input type="hidden" name="tripId" value={tripId} />
      <input type="hidden" name="seat" value={sel ?? ""} />
      <div className="mx-auto max-w-sm rounded-3xl border-4 border-slate-300 bg-white p-4">
        <div className="mb-3 grid grid-cols-[1fr_1.6fr] gap-2 text-[11px] font-semibold text-slate-500">
          <div className="flex h-9 items-center justify-center rounded-lg border-2 border-dashed border-slate-300">السائق 🧑‍✈️</div>
          <div className="flex h-9 items-center justify-center rounded-lg border-2 border-dashed border-slate-300">🚪 باب أمامي</div>
        </div>
        <div className="space-y-2">
          {rows.map((row, i) => (
            <div key={i} className="contents">
              <div className="grid grid-cols-4 gap-2">{row.map((n) => seat(n))}</div>
              {i === 2 && total > 12 && (
                <div className="flex h-7 items-center justify-center rounded-lg bg-amber-100 text-[10px] font-bold text-amber-700">
                  🚪 باب خروج (طوارئ)
                </div>
              )}
            </div>
          ))}
        </div>
        <div className="mt-3 flex h-9 items-center justify-center rounded-lg border-2 border-dashed border-slate-300 text-[11px] font-semibold text-slate-500">
          🚪 باب خلفي
        </div>
      </div>
      {openCount === 0 ? (
        <div className="mt-3 rounded-xl bg-amber-50 p-3 text-center text-sm text-amber-800">
          لا توجد مقاعد مفتوحة للحجز حالياً في هذه الرحلة
        </div>
      ) : (
        <div className="mt-3 flex flex-wrap justify-center gap-x-4 gap-y-1 text-xs text-slate-500">
          <span className="inline-flex items-center gap-1"><i className="inline-block h-3 w-3 rounded border border-emerald-400 bg-emerald-50" /> متاح للحجز</span>
          <span className="inline-flex items-center gap-1"><i className="inline-block h-3 w-3 rounded bg-primary" /> مقعدك</span>
          <span className="inline-flex items-center gap-1"><i className="inline-block h-3 w-3 rounded bg-slate-700" /> محجوز</span>
          <span className="inline-flex items-center gap-1"><i className="inline-block h-3 w-3 rounded border border-slate-200 bg-slate-100" /> محجوزة من الشركة 🔒</span>
        </div>
      )}
      <div className="mt-4 flex items-center justify-between rounded-2xl bg-white p-4 ring-1 ring-slate-200">
        <div className="text-sm">
          {sel ? (
            <>
              المقعد <b>{sel}</b> — {priceLabel}
            </>
          ) : (
            <span className="text-slate-500">اختر مقعداً أخضر للمتابعة</span>
          )}
        </div>
        <button disabled={!sel} className="rounded-xl bg-primary px-5 py-2.5 text-sm font-semibold text-white disabled:opacity-40">
          متابعة الحجز
        </button>
      </div>
    </form>
  );
}

type BD = new (o: { formats: string[] }) => { detect: (v: HTMLVideoElement) => Promise<{ rawValue: string }[]> };

export function Scanner() {
  const router = useRouter();
  const video = useRef<HTMLVideoElement>(null);
  const [on, setOn] = useState(false);
  const [err, setErr] = useState("");
  useEffect(() => {
    if (!on) return;
    let stop = false;
    let stream: MediaStream | null = null;
    (async () => {
      try {
        const Det = (window as unknown as { BarcodeDetector?: BD }).BarcodeDetector;
        if (!Det) {
          setErr("المتصفح لا يدعم مسح الباركود، استخدم الإدخال اليدوي.");
          setOn(false);
          return;
        }
        const det = new Det({ formats: ["qr_code"] });
        stream = await navigator.mediaDevices.getUserMedia({ video: { facingMode: "environment" } });
        const v = video.current!;
        v.srcObject = stream;
        await v.play();
        const tick = async () => {
          if (stop) return;
          try {
            const codes = await det.detect(v);
            if (codes[0]) {
              setOn(false);
              router.push(`?code=${encodeURIComponent(codes[0].rawValue)}`);
              return;
            }
          } catch {}
          requestAnimationFrame(tick);
        };
        tick();
      } catch {
        setErr("تعذر فتح الكاميرا");
        setOn(false);
      }
    })();
    return () => {
      stop = true;
      stream?.getTracks().forEach((t) => t.stop());
    };
  }, [on, router]);
  return (
    <div>
      <button
        type="button"
        onClick={() => {
          setErr("");
          setOn(!on);
        }}
        className="rounded-xl border border-slate-300 bg-white px-4 py-2.5 text-sm font-semibold text-slate-700"
      >
        📷 {on ? "إيقاف الكاميرا" : "مسح بالكاميرا"}
      </button>
      {err && <p className="mt-2 text-xs text-red-600">{err}</p>}
      {on && <video ref={video} className="mt-3 w-full max-w-sm rounded-2xl bg-black" muted playsInline />}
    </div>
  );
}

type BIPEvent = Event & { prompt: () => Promise<void> };

export function InstallPrompt({ app, label }: { app: "passenger" | "company" | "admin"; label: string }) {
  const [evt, setEvt] = useState<BIPEvent | null>(null);
  const [ios, setIos] = useState(false);
  const [hidden, setHidden] = useState(true);
  const [help, setHelp] = useState(false);
  useEffect(() => {
    if ("serviceWorker" in navigator) {
      navigator.serviceWorker.register(`/${app}/sw.js`, { scope: `/${app}/` }).catch(() => {});
    }
    const standalone =
      window.matchMedia("(display-mode: standalone)").matches ||
      (navigator as unknown as { standalone?: boolean }).standalone === true;
    if (standalone || sessionStorage.getItem(`dismiss-${app}`)) return;
    setHidden(false);
    setIos(/iphone|ipad|ipod/i.test(navigator.userAgent));
    const h = (e: Event) => {
      e.preventDefault();
      setEvt(e as BIPEvent);
    };
    window.addEventListener("beforeinstallprompt", h);
    window.addEventListener("appinstalled", () => setHidden(true));
    return () => window.removeEventListener("beforeinstallprompt", h);
  }, [app]);
  if (hidden) return null;
  return (
    <div className="no-print bg-slate-900 px-4 py-2 text-xs text-white">
      <div className="mx-auto flex max-w-6xl items-center justify-between gap-3">
        <span>📲 ثبّت {label} على جهازك للوصول السريع</span>
        <div className="flex items-center gap-2">
          <button
            className="rounded-lg bg-white px-3 py-1 font-semibold text-slate-900"
            onClick={async () => {
              if (evt) {
                await evt.prompt();
                setEvt(null);
              } else setHelp(!help);
            }}
          >
            تثبيت
          </button>
          <button
            className="px-1 text-slate-300"
            onClick={() => {
              sessionStorage.setItem(`dismiss-${app}`, "1");
              setHidden(true);
            }}
            aria-label="إغلاق"
          >
            ✕
          </button>
        </div>
      </div>
      {help && (
        <p className="mx-auto mt-2 max-w-6xl text-slate-300">
          {ios
            ? "على آيفون: اضغط زر المشاركة في Safari ثم «إضافة إلى الشاشة الرئيسية»."
            : "من قائمة المتصفح (⋮) اختر «تثبيت التطبيق» أو «إضافة إلى الشاشة الرئيسية»."}
        </p>
      )}
    </div>
  );
}
