import type { ReactNode } from "react";
import { info, type Tone } from "@/lib/format";

export const cx = (...a: (string | false | null | undefined)[]) => a.filter(Boolean).join(" ");

export const inputCls =
  "w-full rounded-xl border border-slate-300 bg-white px-3 py-2.5 text-sm outline-none transition focus:border-primary focus:ring-2 focus:ring-primary/20 disabled:bg-slate-100";

type Variant = "primary" | "outline" | "danger" | "success" | "warn" | "ghost";
const variants: Record<Variant, string> = {
  primary: "bg-primary text-white hover:opacity-90",
  outline: "border border-slate-300 bg-white text-slate-700 hover:bg-slate-50",
  danger: "bg-red-600 text-white hover:bg-red-700",
  success: "bg-emerald-600 text-white hover:bg-emerald-700",
  warn: "bg-amber-500 text-white hover:bg-amber-600",
  ghost: "text-primary hover:bg-primary/10",
};
export function btnCls(v: Variant = "primary", small = false) {
  return cx(
    "inline-flex items-center justify-center gap-1 rounded-xl font-semibold transition disabled:opacity-50 disabled:cursor-not-allowed cursor-pointer",
    small ? "px-3 py-1.5 text-xs" : "px-4 py-2.5 text-sm",
    variants[v],
  );
}

export const th = "whitespace-nowrap bg-slate-50 px-3 py-2.5 text-right text-xs font-semibold text-slate-500";
export const td = "whitespace-nowrap px-3 py-2.5 text-sm text-slate-700";

export function Card({ children, className }: { children: ReactNode; className?: string }) {
  return <div className={cx("rounded-2xl bg-white p-4 shadow-sm ring-1 ring-slate-200", className)}>{children}</div>;
}

export function PageTitle({ title, subtitle, actions }: { title: string; subtitle?: string; actions?: ReactNode }) {
  return (
    <div className="mb-4 flex flex-wrap items-center justify-between gap-3">
      <div>
        <h1 className="text-xl font-bold text-slate-900">{title}</h1>
        {subtitle && <p className="mt-0.5 text-sm text-slate-500">{subtitle}</p>}
      </div>
      {actions && <div className="flex flex-wrap items-center gap-2">{actions}</div>}
    </div>
  );
}

const tones: Record<Tone, string> = {
  green: "bg-emerald-100 text-emerald-700",
  red: "bg-red-100 text-red-700",
  amber: "bg-amber-100 text-amber-800",
  blue: "bg-blue-100 text-blue-700",
  gray: "bg-slate-100 text-slate-600",
  teal: "bg-teal-100 text-teal-700",
  orange: "bg-orange-100 text-orange-700",
  purple: "bg-purple-100 text-purple-700",
};

export function Badge({ tone = "gray", children }: { tone?: Tone; children: ReactNode }) {
  return (
    <span className={cx("inline-block whitespace-nowrap rounded-full px-2.5 py-0.5 text-xs font-semibold", tones[tone])}>
      {children}
    </span>
  );
}

export function StatusBadge({ map, value }: { map: Record<string, { label: string; tone: Tone }>; value: string | null | undefined }) {
  const i = info(map, value);
  return <Badge tone={i.tone}>{i.label}</Badge>;
}

export function StatCard({ label, value, hint, icon }: { label: string; value: ReactNode; hint?: string; icon?: string }) {
  return (
    <div className="rounded-2xl bg-white p-4 shadow-sm ring-1 ring-slate-200">
      <div className="flex items-center justify-between text-slate-500">
        <span className="text-xs font-semibold">{label}</span>
        {icon && <span className="text-lg">{icon}</span>}
      </div>
      <div className="mt-2 text-2xl font-bold text-slate-900">{value}</div>
      {hint && <div className="mt-1 text-xs text-slate-400">{hint}</div>}
    </div>
  );
}

type SP = Record<string, string | string[] | undefined>;
export function Flash({ sp }: { sp: SP }) {
  const ok = Array.isArray(sp.ok) ? sp.ok[0] : sp.ok;
  const error = Array.isArray(sp.error) ? sp.error[0] : sp.error;
  if (!ok && !error) return null;
  return (
    <div
      className={cx(
        "mb-4 rounded-xl px-4 py-3 text-sm font-medium",
        error ? "bg-red-50 text-red-700 ring-1 ring-red-200" : "bg-emerald-50 text-emerald-700 ring-1 ring-emerald-200",
      )}
    >
      {error || ok}
    </div>
  );
}

export function Field({ label, children, hint }: { label: string; children: ReactNode; hint?: string }) {
  return (
    <label className="block">
      <span className="mb-1 block text-xs font-semibold text-slate-600">{label}</span>
      {children}
      {hint && <span className="mt-1 block text-xs text-slate-400">{hint}</span>}
    </label>
  );
}

export function Empty({ text, icon = "🗂️" }: { text: string; icon?: string }) {
  return (
    <div className="rounded-2xl border border-dashed border-slate-300 bg-white/60 px-4 py-10 text-center text-sm text-slate-500">
      <div className="mb-2 text-3xl">{icon}</div>
      {text}
    </div>
  );
}

export function Logo({ src, name, size = 40 }: { src?: string | null; name: string; size?: number }) {
  if (src)
    // eslint-disable-next-line @next/next/no-img-element
    return <img src={src} alt={name} width={size} height={size} className="rounded-xl object-cover" style={{ width: size, height: size }} />;
  return (
    <div
      className="flex items-center justify-center rounded-xl bg-primary/10 font-bold text-primary"
      style={{ width: size, height: size, fontSize: size * 0.45 }}
    >
      {name.trim().charAt(0)}
    </div>
  );
}

export function Row({ k, v }: { k: string; v: ReactNode }) {
  return (
    <div className="flex items-start justify-between gap-3 border-b border-slate-100 py-2 text-sm last:border-0">
      <span className="text-slate-500">{k}</span>
      <span className="text-left font-medium text-slate-800">{v}</span>
    </div>
  );
}
