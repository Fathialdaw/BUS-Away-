import QRCode from "qrcode";
import { Logo, StatusBadge } from "@/components/ui";
import { fmtDate, fmtTime, money, paymentStatus, ticketStatus } from "@/lib/format";
import type { getTicketData } from "@/lib/booking";
import type { Settings } from "@/lib/settings";

type Data = NonNullable<Awaited<ReturnType<typeof getTicketData>>>;

export async function TicketView({ d, s }: { d: Data; s: Settings }) {
  const svg = await QRCode.toString(d.ticket.qrCode, { type: "svg", margin: 1, width: 170, color: { dark: "#0f172a", light: "#ffffff" } });
  const cell = (k: string, v: React.ReactNode) => (
    <div>
      <div className="text-[11px] text-slate-400">{k}</div>
      <div className="text-sm font-bold text-slate-900">{v}</div>
    </div>
  );
  return (
    <div className="print-surface mx-auto max-w-md overflow-hidden rounded-3xl bg-white shadow-lg ring-1 ring-slate-200">
      <div className="flex items-center justify-between bg-primary px-5 py-4 text-white">
        <div className="flex items-center gap-2">
          <Logo src={d.company.logo} name={d.company.name} size={36} />
          <div>
            <div className="text-sm font-bold">{d.company.name}</div>
            <div className="text-[11px] opacity-80">{d.company.phone}</div>
          </div>
        </div>
        <div className="text-left">
          <div className="text-xs font-bold">{s.app_name}</div>
          <div className="text-[11px] opacity-80">تذكرة إلكترونية</div>
        </div>
      </div>
      <div className="px-5 py-4">
        <div className="flex items-center justify-center gap-3 text-xl font-extrabold text-slate-900">
          <span>{d.trip.fromCity}</span>
          <span className="text-primary">←</span>
          <span>{d.trip.toCity}</span>
        </div>
        <div className="mt-4 grid grid-cols-2 gap-4">
          {cell("اسم الراكب", d.passenger.name)}
          {cell("رقم الراكب", d.passenger.passengerNumber)}
          {cell("رقم الحجز", d.booking.bookingNumber)}
          {cell("رقم التذكرة", d.ticket.ticketNumber)}
          {cell("تاريخ الرحلة", fmtDate(d.trip.departureDate))}
          {cell("وقت المغادرة", fmtTime(d.trip.departureTime))}
          {cell("رقم المقعد", <span className="text-2xl text-primary">{d.booking.seatNumber}</span>)}
          {cell("سعر التذكرة", money(d.booking.price, s.currency))}
          {cell("طريقة الدفع", d.payment?.paymentMethod ?? "-")}
          {cell("حالة الدفع", d.payment ? <StatusBadge map={paymentStatus} value={d.payment.status} /> : "-")}
          {cell("مكان التجمع", d.trip.meetingPoint ?? "-")}
          {cell("حالة التذكرة", <StatusBadge map={ticketStatus} value={d.ticket.status} />)}
        </div>
      </div>
      <div className="relative border-t-2 border-dashed border-slate-300 px-5 py-4">
        <div className="absolute -top-3 -right-3 h-6 w-6 rounded-full bg-slate-100" />
        <div className="absolute -top-3 -left-3 h-6 w-6 rounded-full bg-slate-100" />
        <div className="flex flex-col items-center gap-1">
          <div className="rounded-xl border border-slate-200 p-1" dangerouslySetInnerHTML={{ __html: svg }} />
          <div className="font-mono text-xs tracking-widest text-slate-600">{d.ticket.ticketNumber}</div>
          <p className="text-center text-[11px] text-slate-400">يُمسح الرمز بواسطة موظف الشركة عند الصعود إلى البص</p>
        </div>
      </div>
    </div>
  );
}
