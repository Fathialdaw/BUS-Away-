import type { notifications } from "@/db/schema";
import { notifAction } from "@/app/passenger/actions";
import { fmtDateTime } from "@/lib/format";

const icons: Record<string, string> = {
  booking_confirmed: "✅",
  reminder: "⏰",
  time_changed: "🕒",
  seat_changed: "💺",
  trip_cancelled: "🚫",
  payment_rejected: "❌",
  payment_edit: "✏️",
  booking_cancelled: "🚫",
  info: "🔔",
};

export function NotificationCard({
  n,
  returnTo,
  actions = true,
}: {
  n: typeof notifications.$inferSelect;
  returnTo: string;
  actions?: boolean;
}) {
  const unread = !n.isRead && !n.isDismissed;
  const btn = "rounded-lg px-3 py-1 text-xs font-semibold";
  return (
    <div className={`rounded-2xl p-4 ring-1 ${unread ? "bg-primary/5 ring-primary/30" : "bg-white ring-slate-200"}`}>
      <div className="flex gap-3">
        <span className="text-2xl">{icons[n.type] ?? "🔔"}</span>
        <div className="flex-1">
          <div className="flex items-start justify-between gap-2">
            <h3 className="text-sm font-bold text-slate-900">{n.title}</h3>
            <span className="whitespace-nowrap text-[10px] text-slate-400">{fmtDateTime(n.createdAt)}</span>
          </div>
          <p className="mt-1 text-sm leading-6 text-slate-600">{n.message}</p>
          {actions && unread && (
            <div className="mt-3 flex gap-2">
              {(
                [
                  ["read", "قراءة التنبيه", "bg-primary text-white"],
                  ["skip", "تجاوز", "bg-slate-200 text-slate-700"],
                  ["dismiss", "إغلاق", "bg-white text-slate-500 ring-1 ring-slate-300"],
                ] as const
              ).map(([op, label, cls]) => (
                <form key={op} action={notifAction}>
                  <input type="hidden" name="op" value={op} />
                  <input type="hidden" name="id" value={n.id} />
                  <input type="hidden" name="returnTo" value={returnTo} />
                  <button className={`${btn} ${cls} cursor-pointer`}>{label}</button>
                </form>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
