import { cookies } from "next/headers";
import { toggleThemeAction } from "@/app/theme-action";

/** زر تبديل الوضع الداكن/العادي — يُحفظ الاختيار في كوكي */
export async function ThemeToggle({ returnTo }: { returnTo: string }) {
  const c = await cookies();
  const dark = c.get("theme")?.value === "dark";
  return (
    <form action={toggleThemeAction.bind(null, returnTo)}>
      <button
        type="submit"
        title={dark ? "الوضع العادي (فاتح)" : "الوضع الداكن"}
        aria-label={dark ? "التبديل إلى الوضع العادي" : "التبديل إلى الوضع الداكن"}
        className="no-print flex h-9 w-9 cursor-pointer items-center justify-center rounded-full bg-white text-lg shadow-sm ring-1 ring-slate-200 transition hover:scale-105 dark:bg-slate-800 dark:ring-slate-700"
      >
        {dark ? "☀️" : "🌙"}
      </button>
    </form>
  );
}
