import { ConfirmButton } from "@/components/client";
import { btnCls, cx } from "@/components/ui";
import type { SeatState } from "@/lib/booking";
import { bulkTripSeatsAction, toggleTripSeatAction } from "@/app/company/actions";

const cell = "flex h-12 w-full flex-col items-center justify-center rounded-lg text-sm font-bold leading-none";

export function ManagerSeatMap({
  tripId,
  total,
  states,
}: {
  tripId: number;
  total: number;
  states: { n: number; state: SeatState }[];
}) {
  const map = new Map(states.map((s) => [s.n, s.state]));
  const counts = {
    open: states.filter((s) => s.state === "open").length,
    booked: states.filter((s) => s.state === "booked").length,
    locked: states.filter((s) => s.state === "locked").length,
  };
  const rows: number[][] = [];
  for (let r = 0; r * 4 < total; r++) rows.push([r * 4 + 1, r * 4 + 2, r * 4 + 3, r * 4 + 4]);
  const seat = (n: number) => {
    if (n > total) return <div key={n} />;
    const st = map.get(n) ?? "locked";
    if (st === "booked")
      return (
        <div key={n} title="محجوز (مباع)" className={`${cell} cursor-not-allowed border-2 border-slate-500 bg-slate-700 text-white`}>
          {n}
          <span className="mt-0.5 text-[9px] font-normal">مباع</span>
        </div>
      );
    const open = st === "open";
    return (
      <form key={n} action={toggleTripSeatAction}>
        <input type="hidden" name="tripId" value={tripId} />
        <input type="hidden" name="seat" value={n} />
        <button
          type="submit"
          title={open ? "اضغط لحظر هذا المقعد" : "اضغط لفتح هذا المقعد"}
          className={cx(
            `${cell} transition`,
            open
              ? "cursor-pointer border-2 border-emerald-500 bg-emerald-500 text-white hover:bg-emerald-600"
              : "cursor-pointer border-2 border-slate-200 bg-slate-100 text-slate-500 hover:bg-slate-200",
          )}
        >
          {n}
          <span className="mt-0.5 text-[9px] font-normal">{open ? "✓ مفتوح" : "🔒 حظر"}</span>
        </button>
      </form>
    );
  };
  return (
    <div className="space-y-4">
      <div className="flex flex-wrap gap-2">
        <form action={bulkTripSeatsAction}>
          <input type="hidden" name="tripId" value={tripId} />
          <input type="hidden" name="status" value="open" />
          <ConfirmButton message={`فتح جميع المقاعد (1 إلى ${total}) للحجز عبر التطبيق؟`} className={btnCls("success", true)}>
            فتح جميع المقاعد
          </ConfirmButton>
        </form>
        <form action={bulkTripSeatsAction}>
          <input type="hidden" name="tripId" value={tripId} />
          <input type="hidden" name="status" value="blocked" />
          <ConfirmButton message="حظر جميع المقاعد؟ لن يستطع الركاب اختيار أي مقعد." className={btnCls("warn", true)}>
            حظر جميع المقاعد
          </ConfirmButton>
        </form>
      </div>
      <div className="flex flex-wrap gap-3 text-xs">
        <span className="rounded-full bg-emerald-100 px-3 py-1 font-semibold text-emerald-700">مفتوح: {counts.open}</span>
        <span className="rounded-full bg-slate-200 px-3 py-1 font-semibold text-slate-600">محظور: {counts.locked}</span>
        <span className="rounded-full bg-slate-700 px-3 py-1 font-semibold text-white">مباع: {counts.booked}</span>
      </div>
      <div className="mx-auto max-w-sm rounded-3xl border-4 border-slate-300 bg-white p-4">
        <div className="mb-3 grid grid-cols-[1fr_1.6fr] gap-2 text-[11px] font-semibold text-slate-500">
          <div className="flex h-9 items-center justify-center rounded-lg border-2 border-dashed border-slate-300">السائق 🧑‍✈️</div>
          <div className="flex h-9 items-center justify-center rounded-lg border-2 border-dashed border-slate-300">🚪 باب أمامي</div>
        </div>
        <div className="space-y-2">
          {rows.map((row, i) => (
            <div key={i} className="contents">
              <div className="grid grid-cols-4 gap-2">{row.map((n) => seat(n))}</div>
              {i === 2 && total > 12 && (
                <div className="flex h-7 items-center justify-center rounded-lg bg-amber-100 text-[10px] font-bold text-amber-700">🚪 باب خروج (طوارئ)</div>
              )}
            </div>
          ))}
        </div>
        <div className="mt-3 flex h-9 items-center justify-center rounded-lg border-2 border-dashed border-slate-300 text-[11px] font-semibold text-slate-500">
          🚪 باب خلفي
        </div>
      </div>
      <p className="text-center text-xs text-slate-500">اضغط على أي مقعد لفتحه أو حظره. المقاعد المحظورة تظهر للركاب كمحجوزة ولا يمكن اختيارها.</p>
    </div>
  );
}
