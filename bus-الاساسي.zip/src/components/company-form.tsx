import { FileUpload } from "@/components/client";
import { Card, Field, btnCls, inputCls } from "@/components/ui";
import type { companies } from "@/db/schema";
import { companyStatus } from "@/lib/format";

export function CompanyForm({
  c,
  action,
}: {
  c?: typeof companies.$inferSelect;
  action: (fd: FormData) => Promise<void>;
}) {
  return (
    <form action={action} className="space-y-4">
      {c && <input type="hidden" name="id" value={c.id} />}
      <Card className="space-y-3">
        <div className="grid gap-3 sm:grid-cols-2">
          <Field label="اسم الشركة *"><input name="name" required defaultValue={c?.name} className={inputCls} /></Field>
          <Field label="رقم الترخيص"><input name="licenseNumber" defaultValue={c?.licenseNumber ?? ""} className={inputCls} /></Field>
          <Field label="الهاتف"><input name="phone" defaultValue={c?.phone ?? ""} className={inputCls} /></Field>
          <Field label="البريد الإلكتروني"><input name="email" type="email" defaultValue={c?.email ?? ""} className={inputCls} /></Field>
          <Field label="العنوان"><input name="address" defaultValue={c?.address ?? ""} className={inputCls} /></Field>
          <Field label="الحالة">
            <select name="status" defaultValue={c?.status ?? "pending"} className={inputCls}>
              {Object.entries(companyStatus).map(([k, v]) => <option key={k} value={k}>{v.label}</option>)}
            </select>
          </Field>
        </div>
        <Field label="الولايات / الخطوط التي تعمل بها"><input name="routes" defaultValue={c?.routes ?? ""} className={inputCls} /></Field>
        <FileUpload name="logo" label="شعار الشركة (من المعرض)" initial={c?.logo} square={512} removable />
      </Card>
      {!c && (
        <Card className="space-y-3">
          <h3 className="text-sm font-bold">حساب مدير المكتب (اختياري)</h3>
          <div className="grid gap-3 sm:grid-cols-2">
            <Field label="الاسم"><input name="managerName" className={inputCls} /></Field>
            <Field label="الهاتف"><input name="managerPhone" className={inputCls} /></Field>
            <Field label="البريد الإلكتروني"><input name="managerEmail" type="email" className={inputCls} /></Field>
            <Field label="كلمة المرور"><input name="managerPassword" type="password" className={inputCls} /></Field>
          </div>
        </Card>
      )}
      <button className={btnCls()}>{c ? "حفظ التعديلات" : "إضافة الشركة"}</button>
    </form>
  );
}
