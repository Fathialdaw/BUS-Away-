import { NextResponse } from "next/server";
import type { NextRequest } from "next/server";

/**
 * فصل التطبيقات عبر النطاقات الفرعية:
 *   passenger.example.com  ->  تطبيق المسافر
 *   company.example.com    ->  تطبيق إدارة الشركات
 *   admin.example.com      ->  تطبيق مدير النظام
 * أما النطاق الرئيسي فيعرض الصفحة الرئيسية (بوابة التطبيقات الثلاثة).
 */
const APP_PREFIX: Record<string, string> = {
  passenger: "/passenger",
  company: "/company",
  admin: "/admin",
};

export function middleware(req: NextRequest) {
  const { pathname } = req.nextUrl;
  // الطلبات داخل نطاق تطبيق (مهما كان النطاق) تمر مباشرة
  if (pathname.startsWith("/passenger") || pathname.startsWith("/company") || pathname.startsWith("/admin")) {
    return NextResponse.next();
  }
  const host = (req.headers.get("host") ?? "").toLowerCase().replace(/:\d+$/, "");
  const label = host.split(".")[0];
  const prefix = APP_PREFIX[label];
  if (!prefix) return NextResponse.next();
  // إعادة التوجيه داخل الخادم بحيث يبقى عنوان النطاق الفرعي ثابتاً في شريط العنوان
  const target = new URL(prefix + (pathname === "/" ? "" : pathname), req.url);
  return NextResponse.rewrite(target);
}

export const config = {
  matcher: ["/", "/((?!_next|api|icons|favicon.ico|.*\\..*).*)"],
};
